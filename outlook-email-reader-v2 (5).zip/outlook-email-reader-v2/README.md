# Outlook 365 Email Automation — Playwright + TypeScript

Automate reading Outlook 365 emails, downloading attachments by name (partial/glob), asserting PDF content, and time-windowed email filtering — with full MFA support.

---

## 📁 Project structure

```
outlook-email-reader/
├── pages/
│   └── OutlookPage.ts        ← Page Object — all Outlook UI interactions
├── tests/
│   └── outlook.spec.ts       ← 9 test cases (TC-01 to TC-09)
├── utils/
│   └── helpers.ts            ← PDF reading, Bajaj assertions, date parsing
├── downloads/                ← Downloaded attachments (auto-created)
├── auth-state.json           ← Saved session cookies (auto-created)
├── .env                      ← All configuration
├── playwright.config.ts
└── tsconfig.json
```

---

## 🚀 Quick start

```bash
npm install
npx playwright install chromium
# Edit .env — set credentials + filters
npx playwright test
```

Run a single test:
```bash
npx playwright test --grep "TC-09"
```

---

## ⚙️ .env configuration

| Variable | Description | Example |
|---|---|---|
| `OUTLOOK_EMAIL` | Your Outlook 365 email | `user@company.com` |
| `OUTLOOK_PASSWORD` | Password | `secret` |
| `MFA_MODE` | `auto` / `push` / `totp` / `sms` | `auto` |
| `DOWNLOAD_DIR` | Where attachments are saved | `./downloads` |
| `TARGET_SUBJECT` | Email subject filter (partial) | `Recipt Term Insurance Naveen` |
| `TARGET_SENDER` | Sender name/email filter (partial) | `NaveenKumar` |
| `EMAIL_RECEIVED_WITHIN_MINUTES` | `0` = no time filter (find all) | `0` |
| `ATTACHMENT_NAME_FILTER` | Attachment name filter | `.pdf` |
| `PDF_ASSERT_CONTAINS` | Keywords that must be in PDF | `NAVEEN KUMAR,0600453655` |
| `BAJAJ_POLICY_NO` | Expected policy number | `0600453655` |
| `BAJAJ_POLICYHOLDER` | Expected policyholder name | `NAVEEN KUMAR M S` |
| `BAJAJ_TOTAL_PREMIUM` | Expected total premium | `62067.96` |
| `BAJAJ_LIFE_PREMIUM` | Expected life premium (80C) | `56943.06` |
| `BAJAJ_FINANCIAL_YEAR` | Financial year on certificate | `2025-2026` |
| *(see .env for all BAJAJ_* fields)* | | |

---

## 🧪 Test cases

| Test | Description |
|---|---|
| **TC-01** | Login to Outlook 365 with MFA (push / TOTP / SMS) |
| **TC-02** | List emails matching subject/sender/time filters |
| **TC-03** | Open email and read body |
| **TC-04** | Find emails that have attachments |
| **TC-05** | Download attachments by name filter (partial/glob/pipe-OR) |
| **TC-06** | Download PDF and assert basic content (size, pages, keywords) |
| **TC-07** | Poll inbox — wait for a new email to arrive |
| **TC-08** | E2E — filter → open → download → assert PDF → save summary |
| **TC-09** ⭐ | **Bajaj Life Insurance** — assert all fields in Premium Paid Certificate |

### TC-09 fields verified (from Premium_Paid_Certificate.pdf)

| Field | Expected |
|---|---|
| Policyholder | NAVEEN KUMAR M S |
| Policy No | 0600453655 |
| Product | LIFE_SHEILD_NEW |
| Sum Assured | 45000000 |
| Total Premium | 62067.96 |
| Life Insurance Premium (Sec 80C) | 56943.06 |
| Health Care Premium (Sec 80D) | 0 |
| Premium Due Date | 19-07-2025 |
| Financial Year | 2025-2026 |
| Issuer | Bajaj Life Insurance |
| Certificate Title | Certificate For Premium Paid |
| Tax section mention | Section 80C |

TC-09 also saves a full JSON report to `downloads/bajaj-assertion-report.json`.

---

## 🐛 Bugs fixed (v2)

### Bug 1 — `getAttachmentCards does not exist` (TypeScript compile error)
Caused by orphaned code from a partial `str_replace` that left the old `getEmailList`
body floating outside any function, breaking compilation of the entire file.
→ **Fix:** Complete file rebuild with clean, correct code.

### Bug 2 — Time filter rejecting all emails
`EMAIL_RECEIVED_WITHIN_MINUTES=5` was discarding emails older than 5 minutes.
→ **Fix:** Changed default to `0` (disabled). Set to `60` for last hour, `1440` for last 24h.

### Bug 3 — Date parser couldn't read Outlook's title attribute format
Outlook stores full date as `"Sun 2/22/2026 11:16 AM"` in the title attribute.
The old parser had no pattern for `DayName M/D/YYYY H:MM AM`.
→ **Fix:** Added regex for `DayName M/D/YYYY H:MM AM` and also `DayName H:MM AM` (past week).

### Bug 4 — Attachment cards not found
Outlook 365 Monarch UI renders attachment cards as `role="button"` with 
`aria-label="<filename>, Download"`. Old selectors didn't cover this pattern.
→ **Fix:** Added selectors for `[aria-label*=", Download"]` and broader Monarch UI patterns.
   Name extraction now strips the ", Download" suffix that Outlook appends.

### Bug 5 — Duplicate emails in list
Same conversation thread appears multiple times in the email list.
→ **Fix:** Deduplication by subject + sender key.

---

## MFA support

| Mode | Behaviour |
|---|---|
| `auto` | Detects MFA screen automatically (recommended) |
| `push` | Waits up to 90s for Authenticator push approval |
| `totp` | Prompts for 6-digit code in terminal |
| `sms`  | Same as totp, for SMS codes |

Session cookies are saved to `auth-state.json` after first login — subsequent
runs skip MFA entirely until the session expires.

---

## Attachment name filter syntax

| Pattern | Behaviour |
|---|---|
| *(empty)* | Download all attachments |
| `.pdf` | Any file ending in .pdf |
| `invoice` | Partial name match |
| `*.pdf` | Glob wildcard |
| `invoice\|receipt` | Pipe-separated OR logic |
