import { test, expect } from '@playwright/test';
import * as dotenv from 'dotenv';
import * as path from 'path';
import * as fs from 'fs';
import { OutlookPage, EmailFilter, EmailInfo } from '../pages/OutlookPage';
import {
  readPdf, savePdfText, listFiles, ensureDir,
  printEmailContent, printPdfContent, printKeywordResults,
  assertPdfKeywords, KeywordAssertion, EmailAssertResult,
  assertBajajCertificate, printBajajResults, BajajCertificateFields,
  PdfResult,
} from '../utils/helpers';

dotenv.config();

// ═══════════════════════════════════════════════════════════════════════════
// CONFIG — driven from .env
// ═══════════════════════════════════════════════════════════════════════════

const EMAIL        = process.env.OUTLOOK_EMAIL    || '';
const PASSWORD     = process.env.OUTLOOK_PASSWORD || '';
const MFA_MODE     = (process.env.MFA_MODE || 'auto') as 'push' | 'totp' | 'sms' | 'auto';
const DOWNLOAD_DIR = process.env.DOWNLOAD_DIR     || './downloads';

const TARGET_SUBJECT    = process.env.TARGET_SUBJECT    || '';
const TARGET_SENDER     = process.env.TARGET_SENDER     || '';
const WITHIN_MINUTES    = parseInt(process.env.EMAIL_RECEIVED_WITHIN_MINUTES || '0', 10);
const ATTACHMENT_FILTER = process.env.ATTACHMENT_NAME_FILTER || '';

const PDF_ASSERT_CONTAINS  = (process.env.PDF_ASSERT_CONTAINS || '')
  .split(',').map((s) => s.trim()).filter(Boolean);
const PDF_ASSERT_MIN_PAGES   = parseInt(process.env.PDF_ASSERT_MIN_PAGES   || '1', 10);
const PDF_ASSERT_MIN_SIZE_KB = parseInt(process.env.PDF_ASSERT_MIN_SIZE_KB || '1', 10);

const POLL_TIMEOUT_MS  = parseInt(process.env.EMAIL_POLL_TIMEOUT_MS  || '300000', 10);
const POLL_INTERVAL_MS = parseInt(process.env.EMAIL_POLL_INTERVAL_MS || '15000',  10);

const BAJAJ: BajajCertificateFields = {
  policyNo:       process.env.BAJAJ_POLICY_NO        || '0600453655',
  productName:    process.env.BAJAJ_PRODUCT_NAME     || 'LIFE_SHEILD',
  policyholder:   process.env.BAJAJ_POLICYHOLDER     || 'NAVEEN KUMAR M S',
  sumAssured:     process.env.BAJAJ_SUM_ASSURED      || '45000000',
  totalPremium:   process.env.BAJAJ_TOTAL_PREMIUM    || '62067.96',
  lifePremium:    process.env.BAJAJ_LIFE_PREMIUM     || '56943.06',
  healthPremium:  process.env.BAJAJ_HEALTH_PREMIUM   || '0',
  premiumDueDate: process.env.BAJAJ_PREMIUM_DUE_DATE || '19-07-2025',
  financialYear:  process.env.BAJAJ_FINANCIAL_YEAR   || '2025-2026',
};

// ═══════════════════════════════════════════════════════════════════════════
// SHARED HELPERS
// ═══════════════════════════════════════════════════════════════════════════

function buildFilter(overrides: Partial<EmailFilter> = {}): EmailFilter {
  return {
    withinMinutes:   WITHIN_MINUTES || undefined,
    subjectContains: TARGET_SUBJECT || undefined,
    senderContains:  TARGET_SENDER  || undefined,
    ...overrides,
  };
}

/** Legacy helper for TC-06 / TC-08 — asserts basic PDF structure + keywords. */
async function assertPdfBasic(pdfPath: string): Promise<PdfResult> {
  const result = await readPdf(pdfPath);
  const W2 = 62;

  console.log(`\n${'─'.repeat(W2)}`);
  console.log(`📄  PDF : ${result.filename}`);
  console.log(`    Size  : ${result.sizeKb.toFixed(1)} KB`);
  console.log(`    Pages : ${result.numPages}`);
  console.log(`    Chars : ${result.text.length}`);
  console.log('\n--- Extracted text (first 700 chars) ---');
  console.log(result.text.slice(0, 700));
  if (result.text.length > 700) console.log(`... [${result.text.length - 700} more chars]`);
  console.log('─'.repeat(W2));

  expect(result.sizeKb,   `PDF must be ≥ ${PDF_ASSERT_MIN_SIZE_KB} KB`).toBeGreaterThanOrEqual(PDF_ASSERT_MIN_SIZE_KB);
  expect(result.numPages, `PDF must have ≥ ${PDF_ASSERT_MIN_PAGES} page(s)`).toBeGreaterThanOrEqual(PDF_ASSERT_MIN_PAGES);
  expect(result.text.trim().length, 'PDF has no extractable text').toBeGreaterThan(0);

  for (const kw of PDF_ASSERT_CONTAINS) {
    const found = result.text.toLowerCase().includes(kw.toLowerCase());
    expect(found, `PDF must contain keyword: "${kw}"`).toBe(true);
    console.log(`✅  Keyword found: "${kw}"`);
  }

  savePdfText(pdfPath, result.text);
  return result;
}

function printConfig() {
  const timeLabel = WITHIN_MINUTES ? `last ${WITHIN_MINUTES} min` : 'all time (no filter)';
  console.log('\n╔══════════════════════════════════════════════════════════╗');
  console.log('║              OUTLOOK AUTOMATION CONFIG                   ║');
  console.log('╠══════════════════════════════════════════════════════════╣');
  console.log(`║  Email              : ${EMAIL.padEnd(34)}║`);
  console.log(`║  MFA mode           : ${MFA_MODE.padEnd(34)}║`);
  console.log(`║  Time window        : ${timeLabel.padEnd(34)}║`);
  console.log(`║  Subject filter     : ${(TARGET_SUBJECT  || '(none)').padEnd(34)}║`);
  console.log(`║  Sender filter      : ${(TARGET_SENDER   || '(none)').padEnd(34)}║`);
  console.log(`║  Attachment filter  : ${(ATTACHMENT_FILTER || '(all)').padEnd(34)}║`);
  console.log(`║  PDF keywords       : ${(PDF_ASSERT_CONTAINS.join(',') || '(none)').padEnd(34)}║`);
  console.log('╚══════════════════════════════════════════════════════════╝\n');
}

// ═══════════════════════════════════════════════════════════════════════════
// GENERIC METHOD — reusable across any test
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GENERIC: Find email by subject → open → print body →
 *          download ALL attachments → print & assert every PDF.
 *
 * @param outlook         OutlookPage instance
 * @param subject         Subject keyword to search for (partial match)
 * @param opts.sender     Optional sender keyword filter
 * @param opts.keywords   Optional array of strings that must appear in every PDF
 * @param opts.downloadDir Where to save attachments (defaults to DOWNLOAD_DIR)
 * @returns               Full result including email body + PDF results + assertion outcomes
 */
async function readEmailAndAssert(
  outlook: OutlookPage,
  subject: string,
  opts: {
    sender?:      string;
    keywords?:    string[];
    downloadDir?: string;
  } = {}
): Promise<EmailAssertResult> {

  const dlDir    = opts.downloadDir ?? DOWNLOAD_DIR;
  const keywords = opts.keywords    ?? PDF_ASSERT_CONTAINS;

  // ── 1. Find email ────────────────────────────────────────────────────────
  console.log(`\n🔍  Searching for email: "${subject}"...`);

  const filter: EmailFilter = {
    subjectContains: subject      || undefined,
    senderContains:  opts.sender  || undefined,
    withinMinutes:   WITHIN_MINUTES || undefined,
  };

  let emails = await outlook.getEmailList(50, filter);

  // Fallback: use Outlook search box if not visible in current list
  if (emails.length === 0 && subject) {
    console.log('    Not in inbox view — using Outlook search...');
    await outlook.searchEmails(subject);
    emails = await outlook.getEmailList(50, { senderContains: opts.sender });
  }

  if (emails.length === 0) {
    throw new Error(`❌  No email found with subject: "${subject}"`);
  }

  const target = emails[0];
  console.log(`    ✅  Found : "${target.subject}"`);
  console.log(`        From  : ${target.sender}`);
  console.log(`        Date  : ${target.receivedDate}`);

  // ── 2. Open email ────────────────────────────────────────────────────────
  console.log('\n📧  Opening email...');
  await outlook.openEmail(target);

  // ── 3. Read & print full body ────────────────────────────────────────────
  console.log('\n📖  Reading email body...');
  const body = await outlook.getEmailBody();
  printEmailContent(target.subject, target.sender, target.receivedDate, body);

  // ── 4. List ALL attachments ──────────────────────────────────────────────
  console.log('\n📎  Listing all attachments...');
  const allCards = await outlook.getAttachmentCards();
  console.log(`    Found ${allCards.length} attachment(s):`);
  allCards.forEach((c) => console.log(`      • ${c.name}`));

  // ── 5. Download ALL attachments ──────────────────────────────────────────
  console.log('\n⬇️   Downloading all attachments...');
  // Pass empty filter string → downloads everything
  const downloaded = await outlook.downloadAttachmentsByName('');
  console.log(`\n    Downloaded ${downloaded.length} file(s):`);
  downloaded.forEach((f) =>
    console.log(`      • ${f.filename}  (${(f.sizeBytes / 1024).toFixed(1)} KB)${f.isPdf ? ' 📄' : ''}`)
  );

  // ── 6. For every PDF: read, print full text, assert keywords ─────────────
  const pdfFiles  = downloaded.filter((f) => f.isPdf);
  const pdfResults: PdfResult[]        = [];
  const allKwResults: KeywordAssertion[] = [];

  if (pdfFiles.length === 0) {
    // Check download dir for any pre-existing PDFs
    const existing = listFiles(dlDir, '.pdf');
    if (existing.length > 0) {
      console.log(`\n    No new PDFs downloaded — using ${existing.length} existing file(s) from ${dlDir}`);
      for (const p of existing) pdfFiles.push({ downloadPath: p, filename: path.basename(p), sizeBytes: fs.statSync(p).size, isPdf: true });
    }
  }

  for (const f of pdfFiles) {
    console.log(`\n📄  Processing PDF: ${f.filename}`);

    const result = await readPdf(f.downloadPath);
    pdfResults.push(result);

    // Print FULL PDF content to console
    printPdfContent(result);

    // Save extracted text as .txt sibling
    savePdfText(f.downloadPath, result.text);

    // Run keyword assertions if any keywords are configured
    if (keywords.length > 0) {
      const kwResults = assertPdfKeywords(result.text, keywords);
      printKeywordResults(result.filename, kwResults);
      allKwResults.push(...kwResults);
    }
  }

  // ── 7. Summary ───────────────────────────────────────────────────────────
  const allPassed = allKwResults.length === 0 || allKwResults.every((r) => r.found);

  const resultSummary: EmailAssertResult = {
    subject:           target.subject,
    sender:            target.sender,
    receivedDate:      target.receivedDate,
    body,
    attachmentNames:   allCards.map((c) => c.name),
    pdfs:              pdfResults,
    keywordResults:    allKwResults,
    allKeywordsPassed: allPassed,
  };

  // Save JSON report
  const reportPath = path.join(dlDir, `report-${Date.now()}.json`);
  fs.writeFileSync(reportPath, JSON.stringify({
    timestamp: new Date().toISOString(),
    email: { subject: target.subject, sender: target.sender, receivedDate: target.receivedDate },
    attachments: allCards.map((c) => c.name),
    pdfs: pdfResults.map((p) => ({
      file: p.filename, sizeKb: p.sizeKb.toFixed(1), pages: p.numPages, chars: p.text.length,
    })),
    keywordAssertions: allKwResults,
    allKeywordsPassed: allPassed,
  }, null, 2), 'utf-8');
  console.log(`\n📋  Report saved → ${reportPath}`);

  return resultSummary;
}

// ═══════════════════════════════════════════════════════════════════════════
// TEST SUITE
// ═══════════════════════════════════════════════════════════════════════════

test.describe('Outlook 365 — Full Automation Suite', () => {
  let outlook: OutlookPage;

  test.beforeAll(() => {
    if (!EMAIL || !PASSWORD) throw new Error('❌  OUTLOOK_EMAIL and OUTLOOK_PASSWORD must be set in .env');
    ensureDir(DOWNLOAD_DIR);
    printConfig();
  });

  test.beforeEach(async ({ page, context }) => {
    outlook = new OutlookPage(page, context, DOWNLOAD_DIR);
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-01 : Login
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-01: Login to Outlook 365 with MFA support', async ({ page }) => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    await expect(page).toHaveURL(/outlook\.office365\.com\/mail/);
    console.log('✅  TC-01 Passed: Login successful');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-02 : Read email list
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-02: Read emails filtered by subject/sender/time', async () => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    const emails = await outlook.getEmailList(50, buildFilter());

    console.log(`\n📨  Found ${emails.length} email(s):\n`);
    emails.forEach((e, i) => {
      console.log(`  [${i + 1}]  Subject    : ${e.subject}`);
      console.log(`        From       : ${e.sender}`);
      console.log(`        Received   : ${e.receivedDate}`);
      console.log(`        Attachment : ${e.hasAttachments ? '✅ Yes' : 'No'}`);
      console.log(`        Preview    : ${e.previewText.slice(0, 100)}\n`);
    });

    expect(emails.length, 'Expected at least 1 matching email').toBeGreaterThan(0);
    console.log('✅  TC-02 Passed');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-03 : Open email and read body
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-03: Open email and read body', async () => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    const emails = await outlook.getEmailList(50, buildFilter());
    if (emails.length === 0) { console.warn('⚠️  No emails match — skipping'); test.skip(); return; }

    await outlook.openEmail(emails[0]);
    const body = await outlook.getEmailBody();
    expect(body.length, 'Email body must not be empty').toBeGreaterThan(0);
    console.log(`\n📖  Body preview:\n${'─'.repeat(62)}\n${body.slice(0, 600)}\n${'─'.repeat(62)}`);
    console.log('✅  TC-03 Passed');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-04 : Find emails with attachments
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-04: Find emails with attachments', async () => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    const emails = await outlook.getEmailList(50, buildFilter({ hasAttachments: true }));

    console.log('\n📎  Emails with attachments:');
    emails.forEach((e, i) =>
      console.log(`  [${i + 1}]  "${e.subject}" — ${e.sender} — ${e.receivedDate}`)
    );

    expect(emails.length, 'Expected at least 1 email with attachment').toBeGreaterThan(0);
    console.log('✅  TC-04 Passed');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-05 : Download attachments by name filter
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-05: Download attachments by name filter', async () => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    const emails = await outlook.getEmailList(50, buildFilter({ hasAttachments: true }));
    if (emails.length === 0) { console.warn('⚠️  No emails with attachments — skipping'); test.skip(); return; }

    await outlook.openEmail(emails[0]);
    const allCards = await outlook.getAttachmentCards();
    console.log(`\n📎  All attachments (${allCards.length}):`);
    allCards.forEach((c) => console.log(`   • ${c.name}`));

    const matched = await outlook.getAttachmentCards(ATTACHMENT_FILTER);
    console.log(`\n🎯  Matched (filter "${ATTACHMENT_FILTER || 'all'}"): ${matched.length}`);
    matched.forEach((c) => console.log(`   ✅  ${c.name}`));
    expect(matched.length, 'No attachments matched filter').toBeGreaterThan(0);

    const downloaded = await outlook.downloadAttachmentsByName(ATTACHMENT_FILTER);
    expect(downloaded.length, 'At least one file should download').toBeGreaterThan(0);
    downloaded.forEach((f) => {
      expect(f.sizeBytes, `${f.filename} must not be empty`).toBeGreaterThan(0);
      console.log(`   ✅  ${f.filename}  (${(f.sizeBytes / 1024).toFixed(1)} KB)`);
    });
    console.log('✅  TC-05 Passed');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-06 : Download PDF and assert basic content
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-06: Download PDF attachment and assert content', async () => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    const emails = await outlook.getEmailList(50, buildFilter({ hasAttachments: true }));
    if (emails.length === 0) { console.warn('⚠️  No matching emails — skipping'); test.skip(); return; }

    await outlook.openEmail(emails[0]);
    const allCards = await outlook.getAttachmentCards();
    console.log(`\n📎  All attachments: ${allCards.length}`);
    allCards.forEach((c) => console.log(`   • ${c.name}`));

    const downloaded = await outlook.downloadAttachmentsByName(ATTACHMENT_FILTER || '.pdf');
    const pdfFiles   = downloaded.filter((f) => f.isPdf);

    if (pdfFiles.length === 0) {
      const existing = listFiles(DOWNLOAD_DIR, '.pdf');
      if (existing.length === 0) { console.warn('⚠️  No PDFs found — skipping'); test.skip(); return; }
      for (const p of existing) await assertPdfBasic(p);
    } else {
      for (const f of pdfFiles) await assertPdfBasic(f.downloadPath);
    }
    console.log('✅  TC-06 Passed');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-07 : Poll inbox — wait for new email
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-07: Poll inbox — wait for email received in last N minutes', async () => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    const minuteWindow = WITHIN_MINUTES || 5;
    const filter = buildFilter({ withinMinutes: minuteWindow });

    console.log(`\n⏰  Waiting for email in last ${minuteWindow} min...`);
    const emails = await outlook.waitForEmail(filter, POLL_TIMEOUT_MS, POLL_INTERVAL_MS);

    expect(emails.length).toBeGreaterThan(0);
    emails.forEach((e) => console.log(`  • "${e.subject}"  from ${e.sender}  at ${e.receivedDate}`));
    console.log('✅  TC-07 Passed');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-08 : E2E — Filter → Open → Read body → Download → Assert PDF
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-08: E2E — Filter → Open → Download → Assert PDF', async ({ page }) => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    await expect(page).toHaveURL(/outlook\.office365\.com\/mail/);

    console.log('\n📬  Step 1: Filter emails...');
    let emails = await outlook.getEmailList(50, buildFilter({ hasAttachments: true }));
    if (emails.length === 0 && TARGET_SUBJECT) {
      console.log('    Searching by subject...');
      await outlook.searchEmails(TARGET_SUBJECT);
      emails = await outlook.getEmailList(50, buildFilter({ hasAttachments: true }));
    }
    if (emails.length === 0) {
      await outlook.goToInbox();
      emails = await outlook.getEmailList(5);
    }
    expect(emails.length, 'At least one email must be found').toBeGreaterThan(0);
    const target = emails[0];
    console.log(`    ✅  Selected: "${target.subject}" (${target.receivedDate})`);

    console.log('\n📧  Step 2: Open email...');
    await outlook.openEmail(target);

    console.log('\n📖  Step 3: Read email body...');
    const body = await outlook.getEmailBody();
    expect(body.length, 'Email body must not be empty').toBeGreaterThan(0);
    console.log(`    Preview: ${body.slice(0, 200)}`);

    console.log('\n📎  Step 4: List all attachments...');
    const allCards = await outlook.getAttachmentCards();
    console.log(`    Total found: ${allCards.length}`);
    allCards.forEach((a) => console.log(`      • ${a.name}`));

    console.log(`\n⬇️   Step 5: Download (filter: "${ATTACHMENT_FILTER || 'all'}")...`);
    const downloaded = await outlook.downloadAttachmentsByName(ATTACHMENT_FILTER);
    if (allCards.length > 0) expect(downloaded.length, 'At least one attachment should download').toBeGreaterThan(0);
    downloaded.forEach((f) => {
      expect(f.sizeBytes, `${f.filename} must not be empty`).toBeGreaterThan(0);
      console.log(`    ✅  ${f.filename}  (${(f.sizeBytes / 1024).toFixed(1)} KB)${f.isPdf ? ' 📄' : ''}`);
    });

    const pdfs = downloaded.filter((f) => f.isPdf);
    console.log(`\n📄  Step 6: Assert PDFs (${pdfs.length} found)...`);
    if (pdfs.length === 0) {
      for (const p of listFiles(DOWNLOAD_DIR, '.pdf')) await assertPdfBasic(p);
    } else {
      for (const f of pdfs) await assertPdfBasic(f.downloadPath);
    }

    const summary = {
      timestamp: new Date().toISOString(),
      email: { subject: target.subject, sender: target.sender, receivedDate: target.receivedDate },
      attachments: { all: allCards.map((a) => a.name), downloaded: downloaded.map((f) => ({ filename: f.filename, sizeKb: (f.sizeBytes / 1024).toFixed(1), isPdf: f.isPdf })) },
    };
    const summaryFile = path.join(DOWNLOAD_DIR, `test-summary-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
    fs.writeFileSync(summaryFile, JSON.stringify(summary, null, 2), 'utf-8');
    console.log(`\n📋  Summary saved → ${summaryFile}`);
    console.log('✅  TC-08 Passed');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-09 : Bajaj Life Insurance — Premium Paid Certificate field assertions
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-09: Bajaj Life Insurance — assert Premium Paid Certificate fields', async ({ page }) => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    await expect(page).toHaveURL(/outlook\.office365\.com\/mail/);

    console.log('\n📬  Step 1: Finding Bajaj insurance email...');
    const bajajFilter: EmailFilter = {
      subjectContains: TARGET_SUBJECT || 'Term Insurance Naveen',
      senderContains:  TARGET_SENDER  || 'NaveenKumar',
      hasAttachments:  true,
      withinMinutes:   WITHIN_MINUTES || undefined,
    };
    let emails = await outlook.getEmailList(50, bajajFilter);
    if (emails.length === 0) {
      await outlook.searchEmails(TARGET_SUBJECT || 'Term Insurance Naveen');
      emails = await outlook.getEmailList(50, { ...bajajFilter, subjectContains: undefined });
    }
    if (emails.length === 0) { console.warn('⚠️  Bajaj insurance email not found'); test.skip(); return; }

    const target = emails[0];
    console.log(`    ✅  Found: "${target.subject}" from ${target.sender} | ${target.receivedDate}`);

    console.log('\n📧  Step 2: Opening email...');
    await outlook.openEmail(target);

    console.log('\n📎  Step 3: Listing attachments...');
    const allCards = await outlook.getAttachmentCards();
    console.log(`    Found ${allCards.length} attachment(s):`);
    allCards.forEach((c) => console.log(`      • ${c.name}`));
    expect(allCards.length, 'At least one attachment must be present').toBeGreaterThan(0);

    console.log('\n⬇️   Step 4: Downloading PDF attachment...');
    const downloaded = await outlook.downloadAttachmentsByName('.pdf');

    let pdfPath: string;
    if (downloaded.length > 0 && downloaded[0].isPdf) {
      pdfPath = downloaded[0].downloadPath;
    } else {
      const existing = listFiles(DOWNLOAD_DIR, '.pdf');
      if (existing.length === 0) { console.warn('⚠️  No PDF found — skipping'); test.skip(); return; }
      pdfPath = existing[0];
    }

    console.log('\n📄  Step 5: Extracting PDF text...');
    const pdfResult = await readPdf(pdfPath);
    console.log(`    File   : ${pdfResult.filename}`);
    console.log(`    Size   : ${pdfResult.sizeKb.toFixed(1)} KB`);
    console.log(`    Pages  : ${pdfResult.numPages}`);
    console.log(`    Chars  : ${pdfResult.text.length}`);
    console.log('\n    --- Extracted text (first 800 chars) ---');
    console.log(pdfResult.text.slice(0, 800));
    console.log('    ---');

    expect(pdfResult.sizeKb,              'PDF must be > 10 KB').toBeGreaterThan(10);
    expect(pdfResult.numPages,            'PDF must have ≥ 1 page').toBeGreaterThanOrEqual(1);
    expect(pdfResult.text.trim().length,  'PDF must have extractable text').toBeGreaterThan(0);

    console.log('\n🧪  Step 6: Asserting Bajaj certificate fields...');
    const assertionResults = assertBajajCertificate(pdfResult.text, BAJAJ);
    printBajajResults(assertionResults);
    for (const r of assertionResults) {
      expect(r.found, `❌  Field "${r.field}" not found — expected: "${r.expected}"`).toBe(true);
    }

    console.log('\n🧪  Step 7: Asserting certificate metadata...');
    const textUpper = pdfResult.text.toUpperCase();
    const metaChecks = [
      { label: 'Issuer (Bajaj Life)',    value: 'BAJAJ LIFE INSURANCE' },
      { label: 'Certificate title',      value: 'CERTIFICATE FOR PREMIUM PAID' },
      { label: 'Sec 80C mention',        value: 'SECTION 80C' },
      { label: 'Income Tax Act mention', value: 'INCOME TAX ACT' },
      { label: 'First Premium type',     value: 'FIRST PREMIUM' },
    ];
    for (const { label, value } of metaChecks) {
      const found = textUpper.includes(value);
      console.log(`  ${found ? '✅' : '❌'}  ${label}: "${value}"`);
      expect(found, `PDF must contain "${value}" (${label})`).toBe(true);
    }

    savePdfText(pdfPath, pdfResult.text);
    const report = {
      timestamp: new Date().toISOString(), pdfFile: pdfResult.filename,
      pdfSizeKb: parseFloat(pdfResult.sizeKb.toFixed(1)), pdfPages: pdfResult.numPages,
      email: { subject: target.subject, sender: target.sender, receivedDate: target.receivedDate },
      bajajExpected: BAJAJ,
      fieldAssertions: assertionResults.map((r) => ({ field: r.field, expected: r.expected, passed: r.found })),
      metaAssertions:  metaChecks.map(({ label, value }) => ({ label, value, passed: textUpper.includes(value) })),
    };
    const reportFile = path.join(DOWNLOAD_DIR, 'bajaj-assertion-report.json');
    fs.writeFileSync(reportFile, JSON.stringify(report, null, 2), 'utf-8');
    console.log(`\n📋  Assertion report saved → ${reportFile}`);
    console.log('✅  TC-09 Passed: All Bajaj certificate fields verified!');
  });

  // ─────────────────────────────────────────────────────────────────────────
  // TC-10 : GENERIC — Pass subject → read body → download ALL → print & assert PDFs
  //
  // This is the reusable generic test. Configure via .env:
  //
  //   TARGET_SUBJECT=Recipt Term Insurance Naveen   ← email to find
  //   TARGET_SENDER=NaveenKumar                     ← optional sender filter
  //   ATTACHMENT_NAME_FILTER=                        ← empty = download ALL
  //   PDF_ASSERT_CONTAINS=NAVEEN KUMAR,0600453655   ← keywords to assert in every PDF
  //
  // The readEmailAndAssert() helper can be called from any custom test:
  //
  //   const result = await readEmailAndAssert(outlook, 'Your Subject', {
  //     sender:   'someone@company.com',
  //     keywords: ['expected text', 'another keyword'],
  //   });
  // ─────────────────────────────────────────────────────────────────────────
  test('TC-10: Generic — read email → print body → download all → print & assert PDFs', async ({ page }) => {
    await outlook.login(EMAIL, PASSWORD, MFA_MODE);
    await expect(page).toHaveURL(/outlook\.office365\.com\/mail/);

    if (!TARGET_SUBJECT) {
      console.warn('⚠️  TARGET_SUBJECT is not set in .env — skipping TC-10');
      test.skip();
      return;
    }

    // ── Call the generic helper ─────────────────────────────────────────────
    const result = await readEmailAndAssert(outlook, TARGET_SUBJECT, {
      sender:   TARGET_SENDER  || undefined,
      keywords: PDF_ASSERT_CONTAINS,      // from PDF_ASSERT_CONTAINS in .env
    });

    // ── Playwright assertions ───────────────────────────────────────────────
    expect(result.body.length, 'Email body must not be empty').toBeGreaterThan(0);
    expect(result.attachmentNames.length, 'At least one attachment expected').toBeGreaterThan(0);
    expect(result.pdfs.length, 'At least one PDF must be present').toBeGreaterThan(0);

    for (const pdf of result.pdfs) {
      expect(pdf.sizeKb,              `${pdf.filename}: must be > 1 KB`).toBeGreaterThan(1);
      expect(pdf.numPages,            `${pdf.filename}: must have ≥ 1 page`).toBeGreaterThanOrEqual(1);
      expect(pdf.text.trim().length,  `${pdf.filename}: must have extractable text`).toBeGreaterThan(0);
    }

    if (result.keywordResults.length > 0) {
      for (const r of result.keywordResults) {
        expect(r.found, `Keyword "${r.keyword}" not found in PDF text`).toBe(true);
      }
    }

    console.log(`\n✅  TC-10 Passed`);
    console.log(`    Email    : "${result.subject}"`);
    console.log(`    Body     : ${result.body.length} chars`);
    console.log(`    Files    : ${result.attachmentNames.join(', ')}`);
    console.log(`    PDFs     : ${result.pdfs.length}`);
    console.log(`    Keywords : ${result.allKeywordsPassed ? '✅ All passed' : '❌ Some failed'}`);
  });
});
