import { Page, BrowserContext, Download } from '@playwright/test';
import * as path from 'path';
import * as fs from 'fs';
import * as readline from 'readline';
import {
  ensureDir,
  attachmentMatchesFilter,
  isWithinLastMinutes,
} from '../utils/helpers';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface EmailInfo {
  index: number;
  subject: string;
  sender: string;
  receivedDate: string;
  hasAttachments: boolean;
  previewText: string;
}

export interface AttachmentCard {
  name: string;
  index: number;
}

export interface AttachmentInfo {
  filename: string;
  downloadPath: string;
  sizeBytes: number;
  isPdf: boolean;
}

export interface EmailFilter {
  withinMinutes?: number;
  subjectContains?: string;
  senderContains?: string;
  hasAttachments?: boolean;
}

// ─── MFA terminal helper ──────────────────────────────────────────────────────

function askForCode(prompt: string): Promise<string> {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    rl.question(prompt, (answer) => { rl.close(); resolve(answer.trim()); });
  });
}

// ─── Page Object ─────────────────────────────────────────────────────────────

export class OutlookPage {
  readonly page: Page;
  readonly context: BrowserContext;
  private downloadDir: string;

  static readonly AUTH_STATE_PATH = path.resolve('./auth-state.json');

  /** Selector for individual email rows in the Outlook 365 Monarch UI */
  private readonly EMAIL_ITEM_SEL = '[role="option"][data-convid]';

  /**
   * Selectors for attachment cards in the reading pane.
   *
   * Confirmed from live page snapshot (Outlook 365 Monarch UI, Feb 2026):
   *   <listbox aria-label="file attachments">
   *     <option aria-label="Premium Paid Certificate (1).pdf Open 218 KB" role="option" />
   *     ...
   *   </listbox>
   *
   * Each option's aria-label follows the pattern: "<filename> Open <size> KB"
   * The "More actions" button inside each option opens a menu with "Download".
   */
  private readonly ATTACHMENT_LISTBOX_SEL =
    '[role="listbox"][aria-label*="file attachment"], ' +
    '[aria-label*="file attachment"][role="listbox"], ' +
    '[aria-label*="attachments"][role="listbox"]';

  private readonly ATTACHMENT_CARD_SEL =
    '[role="listbox"][aria-label*="file attachment"] [role="option"], ' +
    '[aria-label*="file attachment"][role="listbox"] [role="option"], ' +
    '[role="listbox"][aria-label*="attachment"] [role="option"]';

  constructor(page: Page, context: BrowserContext, downloadDir: string) {
    this.page = page;
    this.context = context;
    this.downloadDir = ensureDir(downloadDir);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // NAVIGATION
  // ═══════════════════════════════════════════════════════════════════════════

  async goto(): Promise<void> {
    await this.page.goto('https://outlook.office365.com/mail/', {
      waitUntil: 'domcontentloaded',
    });
  }

  async goToInbox(): Promise<void> {
    const link = this.page
      .locator('[aria-label="Inbox"], [title="Inbox"], a:has-text("Inbox")')
      .first();
    if (await link.isVisible({ timeout: 3000 }).catch(() => false)) {
      await link.click();
    } else {
      await this.page.goto('https://outlook.office365.com/mail/inbox', {
        waitUntil: 'domcontentloaded',
      });
    }
    await this.page.waitForSelector(this.EMAIL_ITEM_SEL, { timeout: 20000 });
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // LOGIN + MFA
  // ═══════════════════════════════════════════════════════════════════════════

  async login(
    email: string,
    password: string,
    mfaMode: 'push' | 'totp' | 'sms' | 'auto' = 'auto'
  ): Promise<void> {
    // ── 1. Try saved session ──────────────────────────────────────────────
    if (fs.existsSync(OutlookPage.AUTH_STATE_PATH)) {
      console.log('♻️  Found saved auth state — trying to reuse...');
      try {
        const saved = JSON.parse(fs.readFileSync(OutlookPage.AUTH_STATE_PATH, 'utf-8'));
        if (saved.cookies?.length) await this.context.addCookies(saved.cookies);
      } catch { /* ignore corrupt file */ }

      await this.goto();
      const ok = await this.page
        .waitForSelector(this.EMAIL_ITEM_SEL, { timeout: 10000 })
        .then(() => true).catch(() => false);

      if (ok && this.page.url().includes('outlook.office365.com/mail')) {
        console.log('✅ Reused saved session — skipped login & MFA\n');
        return;
      }
      console.log('⚠️  Saved session expired — doing fresh login...');
    }

    // ── 2. Navigate → Microsoft login ────────────────────────────────────
    console.log('🔐 Logging into Outlook 365...');
    await this.goto();
    await this.page.waitForURL(/login\.microsoftonline\.com/, { timeout: 20000 });

    await this.page.waitForSelector('input[type="email"], input[name="loginfmt"]', { timeout: 10000 });
    await this.page.fill('input[type="email"], input[name="loginfmt"]', email);
    await this.page.click('input[type="submit"], button[type="submit"]');

    await this.page.waitForSelector('input[type="password"]', { timeout: 15000 });
    await this.page.fill('input[type="password"]', password);
    await this.page.click('input[type="submit"], button[type="submit"]');

    // ── 3. Handle MFA ─────────────────────────────────────────────────────
    await this._handleMfa(mfaMode);

    // ── 4. Dismiss "Stay signed in?" ─────────────────────────────────────
    const kmsi = this.page.locator('#idBtn_Back, button:has-text("No")');
    if (await kmsi.first().isVisible({ timeout: 8000 }).catch(() => false)) {
      await kmsi.first().click().catch(() => {});
      console.log('ℹ️  Dismissed "Stay signed in?" prompt');
    }

    // ── 5. Wait for inbox ─────────────────────────────────────────────────
    await this.page.waitForURL(/outlook\.office365\.com\/mail/, { timeout: 40000 });
    await this.page.waitForSelector(
      `${this.EMAIL_ITEM_SEL}, [role="list"][aria-label*="Message"], .ms-List`,
      { timeout: 30000 }
    );

    // ── 6. Persist session ────────────────────────────────────────────────
    await this._saveAuthState();
    console.log('✅ Login successful\n');
  }

  private async _handleMfa(mfaMode: 'push' | 'totp' | 'sms' | 'auto'): Promise<void> {
    await this.page.waitForTimeout(2500);

    const url = this.page.url();
    if (url.includes('outlook.office365.com') || url.includes('KmsiInterrupt')) {
      console.log('ℹ️  No MFA required — continuing');
      return;
    }

    const bodyText = await this.page.locator('body').innerText().catch(() => '');

    const isPushScreen =
      bodyText.includes('Approve sign-in request') ||
      bodyText.includes('open the Microsoft Authenticator') ||
      bodyText.includes('approve the sign-in');

    const isNumberMatchScreen =
      bodyText.includes('Enter the number shown') ||
      bodyText.includes('number shown to sign in') ||
      (await this.page.locator('#idRichContext_DisplaySign, [data-testid="numberMatchChallenge"]')
        .isVisible({ timeout: 500 }).catch(() => false));

    const isOtpScreen =
      bodyText.includes('Enter code') ||
      bodyText.includes('verification code') ||
      bodyText.includes('one-time password') ||
      bodyText.includes('authenticator app code') ||
      (await this.page.locator('input[name="otc"], input[autocomplete="one-time-code"]')
        .isVisible({ timeout: 500 }).catch(() => false));

    if ((isPushScreen || mfaMode === 'push') && mfaMode !== 'totp' && mfaMode !== 'sms') {
      await this._handlePushMfa();
    } else if (isNumberMatchScreen) {
      await this._handleNumberMatchMfa();
    } else if (isOtpScreen || mfaMode === 'totp' || mfaMode === 'sms') {
      await this._handleOtpMfa();
    } else {
      console.log('ℹ️  MFA screen not identified — waiting 5s and continuing...');
      await this.page.waitForTimeout(5000);
    }
  }

  private async _handlePushMfa(): Promise<void> {
    console.log('\n📱 ══════════════════════════════════════════════════════');
    console.log('   MFA — Microsoft Authenticator Push Notification');
    console.log('   ➤  Open the Authenticator app on your phone');
    console.log('   ➤  Tap  APPROVE  on the sign-in request');
    console.log('   ⏳  Waiting up to 90 seconds...');
    console.log('══════════════════════════════════════════════════════\n');

    const start = Date.now();
    while (Date.now() - start < 90_000) {
      await this.page.waitForTimeout(3000);
      const url = this.page.url();
      if (url.includes('outlook.office365.com') || /KmsiInterrupt|kmsi/i.test(url)) {
        console.log('\n✅ Push approved!');
        return;
      }
      const fallback = this.page.locator(
        'a:has-text("use a different verification option"), ' +
        'a:has-text("I can\'t use my Microsoft Authenticator app right now")'
      );
      if (await fallback.isVisible({ timeout: 500 }).catch(() => false)) {
        console.log('\n⚠️  Push timed out — switching to OTP fallback...');
        await fallback.first().click();
        await this._handleOtpMfa();
        return;
      }
      const elapsed = Math.round((Date.now() - start) / 1000);
      process.stdout.write(`\r   ⏳ Waiting for Authenticator approval... ${elapsed}s / 90s`);
    }
    throw new Error('❌ Microsoft Authenticator push timed out after 90s.');
  }

  private async _handleNumberMatchMfa(): Promise<void> {
    const numEl = this.page
      .locator('#idRichContext_DisplaySign, [data-testid="numberMatchChallenge"], [class*="displaySign"]')
      .first();

    let displayNumber = '??';
    try {
      displayNumber = (await numEl.innerText({ timeout: 5000 })).trim();
    } catch {
      const match = (await this.page.locator('body').innerText()).match(/\b(\d{2})\b/);
      if (match) displayNumber = match[1];
    }

    console.log(`\n📱  MFA — Number Match: enter  ${displayNumber}  in Authenticator`);
    await this.page.waitForURL(/outlook\.office365\.com|KmsiInterrupt|kmsi/, { timeout: 90_000 });
    console.log('✅ Number match approved!');
  }

  private async _handleOtpMfa(): Promise<void> {
    const otpInput = this.page.locator('input[name="otc"], input[autocomplete="one-time-code"]');
    if (!(await otpInput.isVisible({ timeout: 3000 }).catch(() => false))) {
      const codeLink = this.page.locator(
        'a:has-text("Enter a code"), a:has-text("Use a verification code"), ' +
        'button:has-text("Use a verification code")'
      );
      if (await codeLink.isVisible({ timeout: 5000 }).catch(() => false)) {
        await codeLink.first().click();
        await this.page.waitForSelector('input[name="otc"], input[autocomplete="one-time-code"]', { timeout: 10000 });
      }
    }

    console.log('\n🔢  MFA — One-Time Password (TOTP / SMS)');
    const code = await askForCode('   🔑 Enter your 6-digit MFA code: ');
    await this.page.fill('input[name="otc"], input[autocomplete="one-time-code"]', code);
    await this.page.click('input[type="submit"], button[type="submit"]');
    await this.page.waitForURL(/outlook\.office365\.com|KmsiInterrupt|kmsi/, { timeout: 30_000 });
    console.log('✅ OTP verified!');
  }

  private async _saveAuthState(): Promise<void> {
    const cookies = await this.context.cookies();
    fs.writeFileSync(
      OutlookPage.AUTH_STATE_PATH,
      JSON.stringify({ cookies, savedAt: new Date().toISOString() }, null, 2),
      'utf-8'
    );
    console.log(`💾 Session saved → ${OutlookPage.AUTH_STATE_PATH}`);
  }

  static clearAuthState(): void {
    if (fs.existsSync(OutlookPage.AUTH_STATE_PATH)) {
      fs.unlinkSync(OutlookPage.AUTH_STATE_PATH);
      console.log('🗑️  Cleared saved auth state');
    }
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // EMAIL LIST — with filtering
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Scans the visible email list and returns EmailInfo[] matching all filters.
   * FIX: Added deduplication (same conversation shows multiple rows),
   *      full date parsing via title attribute, and debug logging for skipped emails.
   */
  async getEmailList(limit = 50, filter: EmailFilter = {}): Promise<EmailInfo[]> {
    await this.page.waitForSelector(
      `${this.EMAIL_ITEM_SEL}, [aria-label*="message list"] [role="option"]`,
      { timeout: 20000 }
    );

    const items = this.page.locator(this.EMAIL_ITEM_SEL);
    const total = Math.min(await items.count(), limit);
    const results: EmailInfo[] = [];

    // Deduplicate by subject + sender (same conversation thread appears multiple times)
    const seen = new Set<string>();

    for (let i = 0; i < total; i++) {
      const item = items.nth(i);

      // ── Subject ────────────────────────────────────────────────────────────
      const subject = (
        await item
          .locator('.TtcXM, [class*="TtcXM"], [class*="IjzWp"] span')
          .first()
          .innerText()
          .catch(async () =>
            (await item.getAttribute('aria-label'))
              ?.split('\n')[0]
              ?.replace(/^(Unread|Has attachments|Forwarded)\s*/gi, '')
              .trim() ?? 'N/A'
          )
      ).trim();

      // ── Sender ─────────────────────────────────────────────────────────────
      const sender = (
        await item
          .locator('.JBWmn, .ESO13, [class*="JBWmn"], [class*="ESO13"]')
          .first()
          .innerText()
          .catch(() => 'N/A')
      ).trim();

      // ── Received date ──────────────────────────────────────────────────────
      // Prefer title attribute: gives "Sun 2/22/2026 11:16 AM" (full datetime)
      const dateEl = item.locator('._rWRU, [class*="_rWRU"]').first();
      const receivedDate = (
        (await dateEl.getAttribute('title').catch(() => null)) ||
        (await dateEl.innerText().catch(() => ''))
      ).trim();

      // ── Has attachments ────────────────────────────────────────────────────
      const ariaLabel = (await item.getAttribute('aria-label')) ?? '';
      const hasAttachments =
        ariaLabel.toLowerCase().includes('has attachments') ||
        (await item
          .locator('[data-icon-name="Attach"], [aria-label="Has attachments"]')
          .isVisible().catch(() => false));

      // ── Preview text ───────────────────────────────────────────────────────
      const previewText = (
        await item
          .locator('.FqgPc, [class*="FqgPc"], [class*="Zgp3k"] span')
          .first()
          .innerText()
          .catch(() => '')
      ).trim();

      // ── Deduplication ──────────────────────────────────────────────────────
      const key = `${subject}|||${sender}`;
      if (seen.has(key)) continue;
      seen.add(key);

      // ── Apply filters ──────────────────────────────────────────────────────
      if (filter.hasAttachments && !hasAttachments) continue;

      if (filter.subjectContains &&
          !subject.toLowerCase().includes(filter.subjectContains.toLowerCase())) continue;

      if (filter.senderContains &&
          !sender.toLowerCase().includes(filter.senderContains.toLowerCase())) continue;

      if (filter.withinMinutes && !isWithinLastMinutes(receivedDate, filter.withinMinutes)) {
        console.log(`    ⏱ Skipped (time filter): "${subject}" — date: "${receivedDate}"`);
        continue;
      }

      results.push({ index: i, subject, sender, receivedDate, hasAttachments, previewText: previewText.slice(0, 200) });
    }

    return results;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // OPEN EMAIL
  // ═══════════════════════════════════════════════════════════════════════════

  /** Opens email at position `index`. Scrolls into view first for virtualized lists. */
  async openEmailByIndex(index: number): Promise<void> {
    const item = this.page.locator(this.EMAIL_ITEM_SEL).nth(index);
    await item.scrollIntoViewIfNeeded({ timeout: 5000 }).catch(() => {});
    await this.page.waitForTimeout(300);
    await item.click();

    // FIXED: Use selectors confirmed from live Outlook DOM snapshot (Feb 2026):
    //   main[aria-label="Reading Pane"]  ← actual reading pane element
    //   [role="document"][aria-label="Message body"]  ← actual body element
    await this.page.waitForSelector(
      'main[aria-label="Reading Pane"], ' +
      '[role="main"][aria-label="Reading Pane"], ' +
      '[role="document"][aria-label="Message body"], ' +
      '[aria-label="Message body"], ' +
      '[role="main"] [class*="ReadingPane"], ' +
      '[role="main"] iframe',
      { timeout: 25000 }
    );
    // Allow attachments / body to fully render
    await this.page.waitForTimeout(1500);
  }

  /** Opens the first email whose subject contains `keyword` (case-insensitive). */
  async openEmailBySubject(keyword: string): Promise<void> {
    const items = this.page.locator(this.EMAIL_ITEM_SEL);
    const count = await items.count();
    for (let i = 0; i < count; i++) {
      const item = items.nth(i);
      const subjectText = await item.locator('.TtcXM, [class*="TtcXM"]').first().innerText().catch(() => '');
      const ariaLabel   = (await item.getAttribute('aria-label')) ?? '';
      if ((subjectText || ariaLabel).toLowerCase().includes(keyword.toLowerCase())) {
        await item.click();
        await this.page.waitForSelector(
          'main[aria-label="Reading Pane"], [role="document"][aria-label="Message body"], ' +
          '[aria-label="Message body"], [role="main"] [class*="ReadingPane"]',
          { timeout: 20000 }
        );
        console.log(`📧 Opened email matching subject: "${keyword}"`);
        return;
      }
    }
    throw new Error(`No email found with subject containing: "${keyword}"`);
  }

  /** Opens email using an EmailInfo object returned by getEmailList(). */
  async openEmail(email: EmailInfo): Promise<void> {
    await this.openEmailByIndex(email.index);
    console.log(`📧 Opened: "${email.subject}" | From: ${email.sender} | ${email.receivedDate}`);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // READ EMAIL BODY
  // ═══════════════════════════════════════════════════════════════════════════

  async getEmailBody(): Promise<string> {
    // FIXED: Confirmed from live page snapshot (Feb 2026):
    //   document "Message body" → [role="document"][aria-label="Message body"]
    // Try that first, then fall back to iframe / older class-based selectors.

    // Strategy 1: role=document with aria-label (confirmed real DOM)
    try {
      const docEl = this.page.locator('[role="document"][aria-label="Message body"], [aria-label="Message body"]').first();
      await docEl.waitFor({ timeout: 6000 });
      const txt = (await docEl.innerText()).trim();
      if (txt.length > 0) return txt;
    } catch { /* not present */ }

    // Strategy 2: iframe (some Outlook configurations)
    const frame = this.page.frameLocator('main[aria-label="Reading Pane"] iframe, [role="main"] iframe').first();
    try {
      const iframeBody = await frame.locator('body').innerText({ timeout: 5000 });
      if (iframeBody.trim().length > 0) return iframeBody.trim();
    } catch { /* iframe not present */ }

    // Strategy 3: fallback class-based selectors
    const loc = this.page.locator(
      '[role="main"] [class*="UniqueMessageBody"], [role="main"] [class*="itemBody"], ' +
      '[role="main"] [class*="ReadingPane"] [class*="body"], ' +
      '[data-testid="message-body"], .ReadMsgBody, #Item\\.UniqueBody'
    );
    await loc.first().waitFor({ timeout: 10000 });
    return (await loc.first().innerText()).trim();
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // ATTACHMENT DISCOVERY
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Returns attachment cards on the open email matching `nameFilter`.
   *
   * CONFIRMED from live page snapshot (Outlook 365, Feb 2026):
   *   <listbox aria-label="file attachments">
   *     <option aria-label="Premium Paid Certificate (1).pdf Open 218 KB" role="option">
   *       <generic aria-label="Premium Paid Certificate (1).pdf" />  ← filename element
   *       <generic>218 KB</generic>
   *       <button "More actions" />
   *     </option>
   *   </listbox>
   *
   * Name extraction: parse option's aria-label → strip trailing " Open NNN KB" or " NNN KB"
   */
  async getAttachmentCards(nameFilter?: string): Promise<AttachmentCard[]> {
    // Wait for the attachment listbox to appear (up to 10s)
    await this.page
      .waitForSelector(this.ATTACHMENT_LISTBOX_SEL, { timeout: 10000 })
      .catch(() => {});

    const cards = this.page.locator(this.ATTACHMENT_CARD_SEL);
    const count  = await cards.count();

    if (count === 0) {
      // Log what's visible for debugging
      const listboxes = await this.page.locator('[role="listbox"]').count();
      console.log(`    ⚠️  No attachment cards found. Listboxes on page: ${listboxes}`);
      // Try logging all listbox aria-labels
      for (let i = 0; i < listboxes; i++) {
        const lb = this.page.locator('[role="listbox"]').nth(i);
        const lbLabel = await lb.getAttribute('aria-label').catch(() => '');
        console.log(`       Listbox[${i}] aria-label: "${lbLabel}"`);
      }
    }

    const results: AttachmentCard[] = [];

    for (let i = 0; i < count; i++) {
      const card = cards.nth(i);
      let name = '';

      // Strategy 1: option aria-label → "Premium Paid Certificate (1).pdf Open 218 KB"
      // Strip " Open NNN KB" or " NNN KB" suffix to get filename
      const aria = (await card.getAttribute('aria-label').catch(() => null)) ?? '';
      if (aria) {
        name = aria
          .replace(/\s+Open\s+[\d.,]+\s*[KMG]B\s*$/i, '')
          .replace(/\s+[\d.,]+\s*[KMG]B\s*$/i, '')
          .trim();
      }

      // Strategy 2: child element with the filename aria-label (generic "Premium Paid Certificate (1).pdf")
      if (!name) {
        const fileEl = card.locator('[aria-label*=".pdf" i], [aria-label*=".xlsx" i], [aria-label*=".docx" i], [aria-label*=".png" i], [aria-label*=".jpg" i]').first();
        const fileAria = await fileEl.getAttribute('aria-label').catch(() => null);
        if (fileAria) name = fileAria.trim();
      }

      // Strategy 3: inner text of filename-looking child span/generic
      if (!name) {
        const inner = await card
          .locator('[aria-label]:not([aria-label="More actions"])')
          .first()
          .getAttribute('aria-label')
          .catch(() => null);
        if (inner) name = inner.replace(/\s+Open\s+[\d.,]+\s*[KMG]B\s*$/i, '').trim();
      }

      // Strategy 4: first line of inner text
      if (!name) {
        const txt = await card.innerText().catch(() => '');
        name = txt.split('\n')[0].trim();
      }

      name = name.trim();
      if (!name) continue;

      console.log(`    📎  Found attachment card[${i}]: "${name}"`);

      if (attachmentMatchesFilter(name, nameFilter ?? '')) {
        results.push({ name, index: i });
      }
    }

    return results;
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // DOWNLOAD ATTACHMENTS
  // ═══════════════════════════════════════════════════════════════════════════

  /**
   * Downloads attachments matching `nameFilter`.
   *
   * CONFIRMED from live page snapshot: each attachment option contains a
   * `button "More actions"` which opens a context menu with a "Download" item.
   * There is also a top-level `button "Download all"` available.
   */
  async downloadAttachmentsByName(nameFilter?: string): Promise<AttachmentInfo[]> {
    const matched = await this.getAttachmentCards(nameFilter);
    const filterLabel = nameFilter ? `"${nameFilter}"` : 'all';

    if (matched.length === 0) {
      console.log(`⚠️  No attachments found matching filter: ${filterLabel}`);
      return [];
    }

    console.log(`\n📎 Attachments to download (filter: ${filterLabel}):`);
    matched.forEach((c) => console.log(`   • ${c.name}`));
    console.log('');

    const cards   = this.page.locator(this.ATTACHMENT_CARD_SEL);
    const results: AttachmentInfo[] = [];

    for (const { name, index } of matched) {
      const card = cards.nth(index);

      try {
        let dl: Download;

        // Strategy 1: Click "More actions" button → "Download" menu item
        // (Confirmed from page snapshot: button "More actions" inside each option)
        const moreBtn = card.locator('button[aria-label="More actions"], button:has-text("More actions")').first();
        const moreBtnVisible = await moreBtn.isVisible({ timeout: 2000 }).catch(() => false);

        if (moreBtnVisible) {
          await moreBtn.click();
          await this.page.waitForTimeout(400);

          // Look for Download in the context menu
          const dlMenuItem = this.page.locator(
            '[role="menu"] [role="menuitem"]:has-text("Download"), ' +
            '[role="menuitem"]:has-text("Download"), ' +
            '[role="option"]:has-text("Download")'
          ).first();

          if (await dlMenuItem.isVisible({ timeout: 3000 }).catch(() => false)) {
            [dl] = await Promise.all([this.page.waitForEvent('download'), dlMenuItem.click()]);
          } else {
            await this.page.keyboard.press('Escape');
            // Strategy 2: hover the card to reveal a direct download button
            await card.hover();
            await this.page.waitForTimeout(300);
            const hoverDlBtn = card.locator('button[aria-label*="Download" i]').first();
            [dl] = await Promise.all([this.page.waitForEvent('download'), hoverDlBtn.click()]);
          }
        } else {
          // Strategy 2: direct click triggers download (some attachment types)
          await card.hover();
          await this.page.waitForTimeout(300);
          [dl] = await Promise.all([this.page.waitForEvent('download'), card.click()]);
        }

        const info = await this._saveDownload(dl);
        results.push(info);
        console.log(
          `⬇️  Downloaded: ${info.filename} (${(info.sizeBytes / 1024).toFixed(1)} KB)` +
          (info.isPdf ? ' 📄' : '')
        );
      } catch (err) {
        console.warn(`⚠️  Failed to download "${name}": ${err}`);
      }
    }

    return results;
  }

  /**
   * Downloads ALL attachments using the "Download all" button confirmed in the page snapshot.
   * Falls back to individual downloads.
   */
  async downloadAllAttachments(): Promise<AttachmentInfo[]> {
    // Confirmed from page snapshot: button "Download all" exists at the top level
    const dlAllBtn = this.page.locator(
      'button[aria-label*="Download all" i], button:has-text("Download all")'
    ).first();

    if (await dlAllBtn.isVisible({ timeout: 3000 }).catch(() => false)) {
      const [dl] = await Promise.all([this.page.waitForEvent('download'), dlAllBtn.click()]);
      return [await this._saveDownload(dl)];
    }
    return this.downloadAttachmentsByName('');
  }

  private async _saveDownload(download: Download): Promise<AttachmentInfo> {
    const filename = download.suggestedFilename();
    const destPath = path.join(this.downloadDir, filename);
    await download.saveAs(destPath);
    const stat = fs.statSync(destPath);
    return {
      filename,
      downloadPath: destPath,
      sizeBytes: stat.size,
      isPdf: filename.toLowerCase().endsWith('.pdf'),
    };
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // SEARCH
  // ═══════════════════════════════════════════════════════════════════════════

  async searchEmails(query: string): Promise<void> {
    const searchInput = this.page.locator('input[placeholder*="Search"], input[aria-label*="Search"]');
    await searchInput.click();
    await searchInput.fill(query);
    await searchInput.press('Enter');
    await this.page.waitForSelector(this.EMAIL_ITEM_SEL, { timeout: 20000 });
    console.log(`🔍 Searched Outlook for: "${query}"`);
  }

  // ═══════════════════════════════════════════════════════════════════════════
  // POLL / WAIT FOR EMAIL
  // ═══════════════════════════════════════════════════════════════════════════

  async waitForEmail(
    filter: EmailFilter,
    timeoutMs = 5 * 60_000,
    intervalMs = 15_000
  ): Promise<EmailInfo[]> {
    const start = Date.now();
    let attempt = 0;

    console.log(
      `\n⏰ Polling for email (timeout: ${timeoutMs / 1000}s, interval: ${intervalMs / 1000}s)`
    );

    while (Date.now() - start < timeoutMs) {
      attempt++;
      console.log(`   Attempt #${attempt} — checking inbox...`);

      await this.page.reload({ waitUntil: 'domcontentloaded' });
      await this.page.waitForSelector(this.EMAIL_ITEM_SEL, { timeout: 15000 }).catch(() => {});

      const emails = await this.getEmailList(50, filter);
      if (emails.length > 0) {
        console.log(`   ✅ Found ${emails.length} email(s) matching filter`);
        return emails;
      }

      const elapsed   = Math.round((Date.now() - start) / 1000);
      const remaining = Math.round((timeoutMs - (Date.now() - start)) / 1000);
      console.log(`   ⌛ Not found — elapsed: ${elapsed}s, remaining: ${remaining}s`);

      if (Date.now() - start + intervalMs < timeoutMs) {
        await this.page.waitForTimeout(intervalMs);
      }
    }

    throw new Error(`Timed out after ${timeoutMs / 1000}s waiting for email: ${JSON.stringify(filter)}`);
  }
}
