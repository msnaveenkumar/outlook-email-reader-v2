import * as fs from 'fs';
import * as path from 'path';
import pdfParse from 'pdf-parse';

// ═══════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════

export interface PdfResult {
  filePath: string;
  filename: string;
  text: string;
  numPages: number;
  sizeKb: number;
  info: Record<string, unknown>;
}

export interface KeywordAssertion {
  keyword: string;
  found: boolean;
  status: '✅ PASS' | '❌ FAIL';
}

export interface EmailAssertResult {
  subject:           string;
  sender:            string;
  receivedDate:      string;
  body:              string;
  attachmentNames:   string[];
  pdfs:              PdfResult[];
  keywordResults:    KeywordAssertion[];
  allKeywordsPassed: boolean;
}

// Legacy Bajaj types (backward compat)
export interface BajajCertificateFields {
  policyNo: string; productName: string; policyholder: string;
  sumAssured: string; totalPremium: string; lifePremium: string;
  healthPremium: string; premiumDueDate: string; financialYear: string;
}
export interface BajajAssertionResult {
  field: string; expected: string; found: boolean; status: '✅ PASS' | '❌ FAIL';
}

// ═══════════════════════════════════════════════════════════════════════════
// FILE UTILITIES
// ═══════════════════════════════════════════════════════════════════════════

export function ensureDir(dirPath: string): string {
  const resolved = path.resolve(dirPath);
  if (!fs.existsSync(resolved)) fs.mkdirSync(resolved, { recursive: true });
  return resolved;
}

export function listFiles(dirPath: string, ext?: string): string[] {
  const resolved = path.resolve(dirPath);
  if (!fs.existsSync(resolved)) return [];
  return fs.readdirSync(resolved)
    .filter((f) => !ext || f.toLowerCase().endsWith(ext))
    .map((f) => path.join(resolved, f));
}

// ═══════════════════════════════════════════════════════════════════════════
// ATTACHMENT MATCHING
// ═══════════════════════════════════════════════════════════════════════════

export function attachmentMatchesFilter(filename: string, filter: string): boolean {
  if (!filter || filter.trim() === '') return true;
  const fname   = filename.toLowerCase();
  const filters = filter.split('|').map((f) => f.trim().toLowerCase()).filter(Boolean);
  return filters.some((f) => {
    if (f === '') return true;
    if (f.includes('*')) {
      const escaped = f.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
      return new RegExp(`^${escaped}$`).test(fname);
    }
    if (f.startsWith('.')) return fname.endsWith(f);
    return fname.includes(f);
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// DATE UTILITIES
// ═══════════════════════════════════════════════════════════════════════════

export function parseOutlookDate(raw: string): Date | null {
  const s = raw.trim();
  const now = new Date();
  if (!s || s === 'N/A') return null;
  if (/just now/i.test(s)) return new Date();

  const minAgo = s.match(/^(\d+)\s*min/i);
  if (minAgo) return new Date(now.getTime() - parseInt(minAgo[1]) * 60_000);

  const hrAgo = s.match(/^(\d+)\s*hr/i);
  if (hrAgo) return new Date(now.getTime() - parseInt(hrAgo[1]) * 3_600_000);

  if (/yesterday/i.test(s)) { const d = new Date(now); d.setDate(d.getDate() - 1); return d; }

  const fullDT = s.match(
    /^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+(\d{1,2}\/\d{1,2}\/\d{4})\s+(\d{1,2}:\d{2}\s*[AP]M)$/i
  );
  if (fullDT) {
    const parsed = new Date(`${fullDT[1]} ${fullDT[2]}`);
    if (!isNaN(parsed.getTime())) return parsed;
  }

  const dayTime = s.match(/^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+(\d{1,2}:\d{2}\s*[AP]M)$/i);
  if (dayTime) {
    const dayMap: Record<string, number> = { sun:0,mon:1,tue:2,wed:3,thu:4,fri:5,sat:6 };
    const target = dayMap[dayTime[1].toLowerCase()];
    const d = new Date(`${now.toDateString()} ${dayTime[2]}`);
    d.setDate(d.getDate() - (now.getDay() - target + 7) % 7);
    return d;
  }

  const timeOnly = s.match(/^(\d{1,2}:\d{2}\s*[AP]M)$/i);
  if (timeOnly) return new Date(`${now.toDateString()} ${timeOnly[0]}`);

  const monDay = s.match(/^([A-Za-z]+)\s+(\d+)$/);
  if (monDay) return new Date(`${monDay[0]} ${now.getFullYear()}`);

  const parsed = new Date(s);
  return isNaN(parsed.getTime()) ? null : parsed;
}

export function isWithinLastMinutes(raw: string, minutes: number): boolean {
  if (!minutes || minutes <= 0) return true;
  const parsed = parseOutlookDate(raw);
  if (!parsed) return true;
  return parsed >= new Date(Date.now() - minutes * 60_000);
}

// ═══════════════════════════════════════════════════════════════════════════
// PDF UTILITIES
// ═══════════════════════════════════════════════════════════════════════════

export async function readPdf(filePath: string): Promise<PdfResult> {
  const absPath = path.resolve(filePath);
  if (!fs.existsSync(absPath)) throw new Error(`PDF not found: ${absPath}`);
  const buffer = fs.readFileSync(absPath);
  const data   = await pdfParse(buffer);
  const stat   = fs.statSync(absPath);
  return {
    filePath: absPath,
    filename: path.basename(absPath),
    text:     data.text,
    numPages: data.numpages,
    sizeKb:   stat.size / 1024,
    info:     data.info as Record<string, unknown>,
  };
}

export function savePdfText(pdfPath: string, text: string): string {
  const outPath = pdfPath.replace(/\.pdf$/i, '_extracted.txt');
  fs.writeFileSync(outPath, text, 'utf-8');
  console.log(`📝  Text saved → ${outPath}`);
  return outPath;
}

// ═══════════════════════════════════════════════════════════════════════════
// CONSOLE PRINTERS
// ═══════════════════════════════════════════════════════════════════════════

const W     = 72;
const LINE  = '═'.repeat(W);
const DLINE = '─'.repeat(W);

function box(title: string): void {
  console.log('\n' + LINE);
  const inner = ` ${title} `;
  const pad   = Math.max(0, W - inner.length);
  const lp    = Math.floor(pad / 2);
  const rp    = pad - lp;
  console.log(`║${' '.repeat(lp)}${inner}${' '.repeat(rp)}║`);
  console.log(LINE);
}

function wrap(text: string, indent = '  '): void {
  const maxW = W - indent.length;
  for (const rawLine of text.split('\n')) {
    const line = rawLine.trimEnd();
    if (line.length === 0) { console.log(''); continue; }
    for (let i = 0; i < line.length; i += maxW) {
      console.log(indent + line.slice(i, i + maxW));
    }
  }
}

/**
 * Prints email metadata + FULL body to the console.
 */
export function printEmailContent(
  subject: string,
  sender: string,
  receivedDate: string,
  body: string
): void {
  box('EMAIL CONTENT');
  console.log(`  Subject  : ${subject}`);
  console.log(`  From     : ${sender}`);
  console.log(`  Received : ${receivedDate}`);
  console.log(DLINE);
  console.log('  BODY:');
  console.log(DLINE);
  wrap(body);
  console.log(LINE + '\n');
}

/**
 * Prints FULL extracted PDF text + metadata to the console.
 */
export function printPdfContent(result: PdfResult): void {
  box(`PDF: ${result.filename}`);
  console.log(`  File    : ${result.filePath}`);
  console.log(`  Size    : ${result.sizeKb.toFixed(1)} KB`);
  console.log(`  Pages   : ${result.numPages}`);
  console.log(`  Chars   : ${result.text.length}`);
  const info = result.info as Record<string, string | undefined>;
  if (info.Author  ) console.log(`  Author  : ${info.Author}`);
  if (info.Creator ) console.log(`  Creator : ${info.Creator}`);
  if (info.Producer) console.log(`  Producer: ${info.Producer}`);
  console.log(DLINE);
  console.log('  FULL EXTRACTED TEXT:');
  console.log(DLINE);
  wrap(result.text);
  console.log(LINE + '\n');
}

// ═══════════════════════════════════════════════════════════════════════════
// GENERIC KEYWORD ASSERTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Generic keyword assertion — checks each keyword against PDF text.
 * Normalises whitespace so PDF line-wrapping does not cause false failures.
 *
 * @param pdfText   Full text extracted from a PDF
 * @param keywords  Strings that must appear in the text
 * @returns         One result object per keyword
 */
export function assertPdfKeywords(
  pdfText: string,
  keywords: string[]
): KeywordAssertion[] {
  // Collapse all whitespace into single space before matching
  const normalised = pdfText.replace(/\s+/g, ' ').toUpperCase();
  return keywords.map((kw) => {
    const normKw = kw.replace(/\s+/g, ' ').toUpperCase();
    const found  = normalised.includes(normKw);
    return { keyword: kw, found, status: found ? '✅ PASS' : '❌ FAIL' };
  });
}

/**
 * Prints keyword assertion results as a formatted table.
 */
export function printKeywordResults(
  filename: string,
  results: KeywordAssertion[]
): void {
  box(`KEYWORD ASSERTIONS — ${filename}`);
  const maxKw = Math.max(...results.map((r) => r.keyword.length), 20);
  console.log(`  ${'KEYWORD'.padEnd(maxKw)}  STATUS`);
  console.log(`  ${'-'.repeat(maxKw)}  -------`);
  for (const r of results) {
    console.log(`  ${r.keyword.padEnd(maxKw)}  ${r.status}`);
  }
  const passed = results.filter((r) => r.found).length;
  const failed = results.length - passed;
  console.log(DLINE);
  console.log(`  Total: ${results.length}   ✅ Passed: ${passed}   ❌ Failed: ${failed}`);
  console.log(LINE + '\n');
}

// ═══════════════════════════════════════════════════════════════════════════
// LEGACY BAJAJ ASSERTIONS  (kept for TC-09)
// ═══════════════════════════════════════════════════════════════════════════

export function assertBajajCertificate(
  pdfText: string,
  expected: BajajCertificateFields
): BajajAssertionResult[] {
  const text = pdfText.replace(/\s+/g, ' ').toUpperCase();
  const checks: Array<{ field: string; expected: string }> = [
    { field: 'Policyholder Name',    expected: expected.policyholder.toUpperCase() },
    { field: 'Policy Number',        expected: expected.policyNo },
    { field: 'Product Name',         expected: expected.productName.toUpperCase() },
    { field: 'Sum Assured',          expected: expected.sumAssured },
    { field: 'Total Premium Amount', expected: expected.totalPremium },
    { field: 'Life Insurance Prem',  expected: expected.lifePremium },
    { field: 'Health Care Premium',  expected: expected.healthPremium },
    { field: 'Premium Due Date',     expected: expected.premiumDueDate },
    { field: 'Financial Year',       expected: expected.financialYear },
  ];
  return checks.map(({ field, expected: val }) => {
    const found = text.includes(val.replace(/\s+/g, ' ').toUpperCase());
    return { field, expected: val, found, status: found ? '✅ PASS' : '❌ FAIL' };
  });
}

export function printBajajResults(results: BajajAssertionResult[]): void {
  const W2 = 62;
  console.log('\n' + '═'.repeat(W2));
  console.log('  BAJAJ LIFE INSURANCE — CERTIFICATE FIELD ASSERTIONS');
  console.log('═'.repeat(W2));
  const maxField = Math.max(...results.map((r) => r.field.length));
  for (const r of results) {
    const pad = ' '.repeat(maxField - r.field.length);
    console.log(`  ${r.status}  ${r.field}${pad}  →  "${r.expected}"`);
  }
  const passed = results.filter((r) => r.found).length;
  console.log('─'.repeat(W2));
  console.log(`  Total: ${results.length}  |  Passed: ${passed}  |  Failed: ${results.length - passed}`);
  console.log('═'.repeat(W2) + '\n');
}
