/**
 * Outlook 365 Automation — Microsoft Graph API Test Suite
 * ─────────────────────────────────────────────────────────
 * Mirrors the Playwright version (TC-01 → TC-10) but uses
 * the Graph API instead of a browser — no Playwright required.
 *
 * Run all:     npx jest --runInBand
 * Run one:     npx jest -t "TC-02"
 */

import * as dotenv from 'dotenv';
import * as path from 'path';
import * as fs from 'fs';

dotenv.config();

import { GraphAuthProvider }  from '../src/auth/GraphAuthProvider';
import { GraphClient }        from '../src/client/GraphClient';
import { EmailReader, EmailFilter } from '../src/email/EmailReader';
import { PdfProcessor }       from '../src/pdf/PdfProcessor';
import { readEmailAndAssert } from '../src/index';
import {
  assertBajajCertificate, printBajajResults, printConfig,
  BajajCertificateFields, ensureDir, listFiles,
} from '../src/utils/helpers';

// ═══════════════════════════════════════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════════════════════════════════════

const USER_EMAIL     = process.env.USER_EMAIL    ?? '';
const AUTH_MODE      = process.env.AUTH_MODE     ?? 'device_code';
const DOWNLOAD_DIR   = process.env.DOWNLOAD_DIR  ?? './downloads';
const TARGET_SUBJECT = process.env.TARGET_SUBJECT ?? '';
const TARGET_SENDER  = process.env.TARGET_SENDER  ?? '';
const WITHIN_MINUTES = parseInt(process.env.EMAIL_RECEIVED_WITHIN_MINUTES ?? '0', 10);
const ATT_FILTER     = process.env.ATTACHMENT_NAME_FILTER ?? '';

const PDF_KEYWORDS    = (process.env.PDF_ASSERT_CONTAINS ?? '')
  .split(',').map((s) => s.trim()).filter(Boolean);
const PDF_MIN_PAGES   = parseInt(process.env.PDF_ASSERT_MIN_PAGES   ?? '1', 10);
const PDF_MIN_SIZE_KB = parseInt(process.env.PDF_ASSERT_MIN_SIZE_KB ?? '1', 10);

const BAJAJ: BajajCertificateFields = {
  policyNo:       process.env.BAJAJ_POLICY_NO        ?? '0600453655',
  productName:    process.env.BAJAJ_PRODUCT_NAME     ?? 'LIFE_SHEILD',
  policyholder:   process.env.BAJAJ_POLICYHOLDER     ?? 'NAVEEN KUMAR M S',
  sumAssured:     process.env.BAJAJ_SUM_ASSURED      ?? '45000000',
  totalPremium:   process.env.BAJAJ_TOTAL_PREMIUM    ?? '62067.96',
  lifePremium:    process.env.BAJAJ_LIFE_PREMIUM     ?? '56943.06',
  healthPremium:  process.env.BAJAJ_HEALTH_PREMIUM   ?? '0',
  premiumDueDate: process.env.BAJAJ_PREMIUM_DUE_DATE ?? '19-07-2025',
  financialYear:  process.env.BAJAJ_FINANCIAL_YEAR   ?? '2025-2026',
};

// ═══════════════════════════════════════════════════════════════════════════
// SHARED — Graph API client (created once, reused across all tests)
// ═══════════════════════════════════════════════════════════════════════════

let graph:  GraphClient;
let reader: EmailReader;

beforeAll(() => {
  if (!process.env.GRAPH_CLIENT_ID || process.env.GRAPH_CLIENT_ID === 'your-client-id-here') {
    throw new Error(
      '❌  GRAPH_CLIENT_ID not configured.\n' +
      '    Register an Azure App and update .env — see README.md.'
    );
  }
  ensureDir(DOWNLOAD_DIR);

  const config = GraphAuthProvider.fromEnv();
  graph  = GraphClient.create(config);
  reader = new EmailReader(graph, DOWNLOAD_DIR);

  printConfig(USER_EMAIL, AUTH_MODE, TARGET_SUBJECT, TARGET_SENDER, WITHIN_MINUTES, ATT_FILTER, PDF_KEYWORDS);
});

function buildFilter(overrides: Partial<EmailFilter> = {}): EmailFilter {
  return {
    subjectContains: TARGET_SUBJECT || undefined,
    senderContains:  TARGET_SENDER  || undefined,
    withinMinutes:   WITHIN_MINUTES || undefined,
    ...overrides,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// TC-01 — Authentication
// ═══════════════════════════════════════════════════════════════════════════

test('TC-01: Authenticate and get access token', async () => {
  console.log(`\n🔐  Testing auth (${AUTH_MODE} mode)...`);
  const config = GraphAuthProvider.fromEnv();
  const auth   = new GraphAuthProvider(config);

  const token = await auth.getAccessToken();
  expect(token).toBeTruthy();
  expect(typeof token).toBe('string');
  expect(token.length).toBeGreaterThan(100); // JWT tokens are long

  console.log(`✅  TC-01 Passed: Token acquired (${token.length} chars)`);
});

// ═══════════════════════════════════════════════════════════════════════════
// TC-02 — List emails
// ═══════════════════════════════════════════════════════════════════════════

test('TC-02: List emails filtered by subject / sender / time', async () => {
  console.log('\n📬  Fetching email list...');
  const emails = await reader.listEmails({ ...buildFilter(), top: 50 });

  console.log(`\n📨  Found ${emails.length} email(s):\n`);
  emails.forEach((e, i) => {
    console.log(`  [${i + 1}]  Subject    : ${e.subject}`);
    console.log(`        From       : ${e.sender}`);
    console.log(`        Received   : ${e.receivedDate}`);
    console.log(`        Attachment : ${e.hasAttachments ? '✅ Yes' : 'No'}`);
    console.log(`        Preview    : ${e.bodyPreview.slice(0, 100)}\n`);
  });

  expect(emails.length).toBeGreaterThan(0);
  for (const e of emails) {
    expect(e.id).toBeTruthy();
    expect(e.subject).toBeTruthy();
    expect(e.sender).toBeTruthy();
    expect(e.receivedDate).toBeTruthy();
  }
  console.log('✅  TC-02 Passed');
});

// ═══════════════════════════════════════════════════════════════════════════
// TC-03 — Open email and read body
// ═══════════════════════════════════════════════════════════════════════════

test('TC-03: Open email and read full body', async () => {
  const emails = await reader.listEmails({ ...buildFilter(), top: 10 });
  if (emails.length === 0) {
    console.warn('⚠️  No matching emails — skipping TC-03');
    return;
  }

  const target = emails[0];
  console.log(`\n📧  Opening: "${target.subject}"`);

  const body = await reader.readEmailBody(target.id);
  expect(body.length).toBeGreaterThan(0);

  console.log(`\n📖  Body (${body.length} chars):`);
  console.log('─'.repeat(62));
  console.log(body.slice(0, 800));
  if (body.length > 800) console.log(`... [${body.length - 800} more chars]`);
  console.log('─'.repeat(62));
  console.log('✅  TC-03 Passed');
});

// ═══════════════════════════════════════════════════════════════════════════
// TC-04 — List emails that have attachments
// ═══════════════════════════════════════════════════════════════════════════

test('TC-04: Find emails with attachments', async () => {
  const emails = await reader.listEmails({ ...buildFilter(), hasAttachments: true, top: 20 });

  console.log(`\n📎  Emails with attachments: ${emails.length}`);
  emails.forEach((e, i) =>
    console.log(`  [${i + 1}]  "${e.subject}"  — ${e.sender}  — ${e.receivedDate}`)
  );

  expect(emails.length).toBeGreaterThan(0);
  for (const e of emails) {
    expect(e.hasAttachments).toBe(true);
  }
  console.log('✅  TC-04 Passed');
});

// ═══════════════════════════════════════════════════════════════════════════
// TC-05 — List attachment metadata
// ═══════════════════════════════════════════════════════════════════════════

test('TC-05: List attachment names and sizes', async () => {
  const emails = await reader.listEmails({ ...buildFilter(), hasAttachments: true, top: 10 });
  if (emails.length === 0) {
    console.warn('⚠️  No emails with attachments — skipping TC-05');
    return;
  }

  const target = emails[0];
  console.log(`\n📧  Checking attachments for: "${target.subject}"`);

  // All attachments
  const allAtts = await reader.listAttachments(target.id);
  console.log(`\n📎  All attachments (${allAtts.length}):`);
  allAtts.forEach((a) => console.log(`   • ${a.name}  (${(a.size / 1024).toFixed(1)} KB, ${a.contentType})`));
  expect(allAtts.length).toBeGreaterThan(0);

  // Filtered attachments
  if (ATT_FILTER) {
    const filtered = await reader.listAttachments(target.id, ATT_FILTER);
    console.log(`\n🎯  Filtered by "${ATT_FILTER}": ${filtered.length}`);
    filtered.forEach((a) => console.log(`   ✅  ${a.name}`));
    expect(filtered.length).toBeGreaterThan(0);
  }

  console.log('✅  TC-05 Passed');
});

// ═══════════════════════════════════════════════════════════════════════════
// TC-06 — Download attachments and assert PDF content (basic)
// ═══════════════════════════════════════════════════════════════════════════

test('TC-06: Download PDF attachment and assert basic content', async () => {
  const emails = await reader.listEmails({ ...buildFilter(), hasAttachments: true, top: 10 });
  if (emails.length === 0) {
    console.warn('⚠️  No matching emails — skipping TC-06');
    return;
  }

  const target = emails[0];
  console.log(`\n📧  Processing: "${target.subject}"`);

  const filter      = ATT_FILTER || '.pdf';
  const downloaded  = await reader.downloadAllAttachments(target.id, filter);
  const pdfFiles    = downloaded.filter((f) => f.isPdf);

  const pdfPaths = pdfFiles.length > 0
    ? pdfFiles.map((f) => f.downloadPath)
    : listFiles(DOWNLOAD_DIR, '.pdf');

  if (pdfPaths.length === 0) {
    console.warn('⚠️  No PDFs found — skipping assertion');
    return;
  }

  for (const pdfPath of pdfPaths) {
    const result = await PdfProcessor.read(pdfPath);
    console.log(`\n📄  PDF: ${result.filename}  (${result.sizeKb.toFixed(1)} KB, ${result.numPages} pages, ${result.text.length} chars)`);
    console.log('--- First 500 chars ---');
    console.log(result.text.slice(0, 500));
    console.log('---');

    expect(result.sizeKb).toBeGreaterThanOrEqual(PDF_MIN_SIZE_KB);
    expect(result.numPages).toBeGreaterThanOrEqual(PDF_MIN_PAGES);
    expect(result.text.trim().length).toBeGreaterThan(0);

    for (const kw of PDF_KEYWORDS) {
      const found = result.text.toLowerCase().includes(kw.toLowerCase());
      expect(found).toBe(true);
      console.log(`✅  Keyword: "${kw}"`);
    }

    PdfProcessor.saveText(pdfPath, result.text);
  }

  console.log('✅  TC-06 Passed');
});

// ═══════════════════════════════════════════════════════════════════════════
// TC-07 — Poll inbox until email arrives (wait-for-email)
// ═══════════════════════════════════════════════════════════════════════════

test('TC-07: Poll inbox — wait for email in last N minutes', async () => {
  const minuteWindow = WITHIN_MINUTES || 5;
  const filter = buildFilter({ withinMinutes: minuteWindow });
  const pollTimeoutMs  = parseInt(process.env.EMAIL_POLL_TIMEOUT_MS  ?? '60000', 10);
  const pollIntervalMs = parseInt(process.env.EMAIL_POLL_INTERVAL_MS ?? '10000', 10);

  console.log(`\n⏰  Polling inbox — looking for email in last ${minuteWindow} min...`);
  const emails = await reader.waitForEmail(filter, pollTimeoutMs, pollIntervalMs);

  expect(emails.length).toBeGreaterThan(0);
  emails.forEach((e) => console.log(`  ✅  "${e.subject}"  from ${e.sender}  at ${e.receivedDate}`));
  console.log('✅  TC-07 Passed');
}, 360_000); // 6 min timeout for polling

// ═══════════════════════════════════════════════════════════════════════════
// TC-08 — E2E: filter → open → body → attachments → download → assert PDF
// ═══════════════════════════════════════════════════════════════════════════

test('TC-08: E2E — Filter → Open → Download → Assert PDF', async () => {

  // Step 1: Find email
  console.log('\n📬  Step 1: Filter emails...');
  let emails = await reader.listEmails({ ...buildFilter(), hasAttachments: true, top: 20 });

  if (emails.length === 0 && TARGET_SUBJECT) {
    console.log('    Inbox miss — searching all folders...');
    emails = await reader.searchEmails(TARGET_SUBJECT);
  }
  if (emails.length === 0) {
    // Fallback: first inbox email regardless of filter
    emails = await reader.listEmails({ top: 5 });
  }

  expect(emails.length).toBeGreaterThan(0);
  const target = emails[0];
  console.log(`    ✅  Selected: "${target.subject}"  (${target.receivedDate})`);

  // Step 2: Body
  console.log('\n📖  Step 2: Reading email body...');
  const body = await reader.readEmailBody(target.id);
  expect(body.length).toBeGreaterThan(0);
  console.log(`    Preview: ${body.slice(0, 200)}`);

  // Step 3: List attachments
  console.log('\n📎  Step 3: List all attachments...');
  const allAtts = await reader.listAttachments(target.id);
  console.log(`    Found: ${allAtts.length}`);
  allAtts.forEach((a) => console.log(`      • ${a.name}  (${(a.size / 1024).toFixed(1)} KB)`));

  // Step 4: Download
  console.log(`\n⬇️   Step 4: Download (filter: "${ATT_FILTER || 'all'}")...`);
  const downloaded = await reader.downloadAllAttachments(target.id, ATT_FILTER);
  if (allAtts.length > 0) expect(downloaded.length).toBeGreaterThan(0);
  downloaded.forEach((f) => {
    expect(f.sizeBytes).toBeGreaterThan(0);
    console.log(`    ✅  ${f.filename}  (${(f.sizeBytes / 1024).toFixed(1)} KB)${f.isPdf ? ' 📄' : ''}`);
  });

  // Step 5: Assert PDFs
  const pdfs = downloaded.filter((f) => f.isPdf);
  console.log(`\n📄  Step 5: Assert ${pdfs.length} PDF(s)...`);
  for (const f of pdfs) {
    const result = await PdfProcessor.read(f.downloadPath);
    expect(result.sizeKb).toBeGreaterThanOrEqual(PDF_MIN_SIZE_KB);
    expect(result.numPages).toBeGreaterThanOrEqual(PDF_MIN_PAGES);
    expect(result.text.trim().length).toBeGreaterThan(0);
    for (const kw of PDF_KEYWORDS) {
      expect(result.text.toLowerCase().includes(kw.toLowerCase())).toBe(true);
      console.log(`    ✅  Keyword: "${kw}"`);
    }
    PdfProcessor.saveText(f.downloadPath, result.text);
  }

  // Step 6: Save JSON summary
  const summary = {
    timestamp:   new Date().toISOString(),
    email:       { subject: target.subject, sender: target.sender, receivedDate: target.receivedDate },
    attachments: { all: allAtts.map((a) => a.name), downloaded: downloaded.map((f) => f.filename) },
  };
  const outPath = path.join(DOWNLOAD_DIR, `tc08-summary-${Date.now()}.json`);
  fs.writeFileSync(outPath, JSON.stringify(summary, null, 2), 'utf-8');
  console.log(`\n📋  Summary → ${outPath}`);
  console.log('✅  TC-08 Passed');
});

// ═══════════════════════════════════════════════════════════════════════════
// TC-09 — Bajaj Life Insurance: field-level certificate assertions
// ═══════════════════════════════════════════════════════════════════════════

test('TC-09: Bajaj Life Insurance — assert Premium Paid Certificate fields', async () => {

  // Step 1: Find Bajaj insurance email
  console.log('\n📬  Step 1: Finding Bajaj insurance email...');
  const bajajFilter: EmailFilter = {
    subjectContains: TARGET_SUBJECT || 'Term Insurance Naveen',
    senderContains:  TARGET_SENDER  || 'NaveenKumar',
    hasAttachments:  true,
    withinMinutes:   WITHIN_MINUTES || undefined,
  };

  let emails = await reader.listEmails({ ...bajajFilter, top: 50 });
  if (emails.length === 0) {
    emails = await reader.searchEmails(TARGET_SUBJECT || 'Term Insurance Naveen');
  }
  if (emails.length === 0) {
    console.warn('⚠️  Bajaj insurance email not found — skipping TC-09');
    return;
  }

  const target = emails[0];
  console.log(`    ✅  Found: "${target.subject}" | ${target.sender} | ${target.receivedDate}`);

  // Step 2: List attachments
  console.log('\n📎  Step 2: Listing attachments...');
  const atts = await reader.listAttachments(target.id);
  console.log(`    Found ${atts.length} attachment(s):`);
  atts.forEach((a) => console.log(`      • ${a.name}  (${(a.size / 1024).toFixed(1)} KB)`));
  expect(atts.length).toBeGreaterThan(0);

  // Step 3: Download PDF
  console.log('\n⬇️   Step 3: Downloading PDF...');
  const downloaded = await reader.downloadAllAttachments(target.id, '.pdf');

  let pdfPath: string;
  if (downloaded.length > 0 && downloaded[0].isPdf) {
    pdfPath = downloaded[0].downloadPath;
  } else {
    const existing = listFiles(DOWNLOAD_DIR, '.pdf');
    if (existing.length === 0) {
      console.warn('⚠️  No PDF found — skipping TC-09');
      return;
    }
    pdfPath = existing[0];
  }

  // Step 4: Extract text
  console.log('\n📄  Step 4: Extracting PDF text...');
  const result = await PdfProcessor.read(pdfPath);
  console.log(`    File  : ${result.filename}`);
  console.log(`    Size  : ${result.sizeKb.toFixed(1)} KB`);
  console.log(`    Pages : ${result.numPages}`);
  console.log(`    Chars : ${result.text.length}`);
  console.log('\n    --- Extracted text (first 800 chars) ---');
  console.log(result.text.slice(0, 800));
  console.log('    ---');

  expect(result.sizeKb).toBeGreaterThan(10);
  expect(result.numPages).toBeGreaterThanOrEqual(1);
  expect(result.text.trim().length).toBeGreaterThan(0);

  // Step 5: Bajaj field assertions
  console.log('\n🧪  Step 5: Asserting Bajaj certificate fields...');
  const assertions = assertBajajCertificate(result.text, BAJAJ);
  printBajajResults(assertions);
  for (const r of assertions) {
    expect(r.found).toBe(true);
  }

  // Step 6: Metadata keyword assertions
  console.log('\n🧪  Step 6: Asserting certificate metadata...');
  const textUpper = result.text.toUpperCase();
  const metaChecks = [
    { label: 'Issuer',            value: 'BAJAJ LIFE INSURANCE' },
    { label: 'Certificate title', value: 'CERTIFICATE FOR PREMIUM PAID' },
    { label: 'Sec 80C',           value: 'SECTION 80C' },
    { label: 'Income Tax Act',    value: 'INCOME TAX ACT' },
    { label: 'First Premium',     value: 'FIRST PREMIUM' },
  ];
  for (const { label, value } of metaChecks) {
    const found = textUpper.includes(value);
    console.log(`  ${found ? '✅' : '❌'}  ${label}: "${value}"`);
    expect(found).toBe(true);
  }

  PdfProcessor.saveText(pdfPath, result.text);

  // Save full assertion report
  const report = {
    timestamp:    new Date().toISOString(),
    pdfFile:      result.filename,
    pdfSizeKb:    parseFloat(result.sizeKb.toFixed(1)),
    pdfPages:     result.numPages,
    email:        { subject: target.subject, sender: target.sender },
    bajajExpected: BAJAJ,
    fieldAssertions: assertions.map((r) => ({ field: r.field, expected: r.expected, passed: r.found })),
    metaAssertions:  metaChecks.map(({ label, value }) => ({ label, value, passed: textUpper.includes(value) })),
  };
  const rpath = path.join(DOWNLOAD_DIR, 'bajaj-assertion-report.json');
  fs.writeFileSync(rpath, JSON.stringify(report, null, 2), 'utf-8');
  console.log(`\n📋  Report → ${rpath}`);
  console.log('✅  TC-09 Passed: All Bajaj certificate fields verified!');
});

// ═══════════════════════════════════════════════════════════════════════════
// TC-10 — GENERIC: readEmailAndAssert (the main reusable method)
//
// Configure via .env:
//   TARGET_SUBJECT=Your Email Subject
//   TARGET_SENDER=sender@company.com    ← optional
//   ATTACHMENT_NAME_FILTER=             ← empty = download ALL
//   PDF_ASSERT_CONTAINS=keyword1,keyword2
//
// Or call readEmailAndAssert() directly from any custom test:
//
//   const result = await readEmailAndAssert(reader, 'Invoice March 2026', {
//     keywords:   ['TOTAL', 'Company Ltd', '2026'],
//     nameFilter: '.pdf',
//   });
//   expect(result.allKeywordsPassed).toBe(true);
// ═══════════════════════════════════════════════════════════════════════════

test('TC-10: Generic — readEmailAndAssert (print body + all PDFs + assert keywords)', async () => {
  if (!TARGET_SUBJECT) {
    console.warn('⚠️  TARGET_SUBJECT not set in .env — skipping TC-10');
    return;
  }

  // ── THE GENERIC CALL ──────────────────────────────────────────────────────
  const result = await readEmailAndAssert(reader, TARGET_SUBJECT, {
    sender:      TARGET_SENDER  || undefined,
    keywords:    PDF_KEYWORDS,         // from PDF_ASSERT_CONTAINS in .env
    nameFilter:  ATT_FILTER,           // from ATTACHMENT_NAME_FILTER in .env
    downloadDir: DOWNLOAD_DIR,
  });

  // ── Jest assertions on the returned result ────────────────────────────────
  expect(result.body.length).toBeGreaterThan(0);
  expect(result.attachmentNames.length).toBeGreaterThan(0);
  expect(result.pdfs.length).toBeGreaterThan(0);

  for (const pdf of result.pdfs) {
    expect(pdf.sizeKb).toBeGreaterThanOrEqual(PDF_MIN_SIZE_KB);
    expect(pdf.numPages).toBeGreaterThanOrEqual(PDF_MIN_PAGES);
    expect(pdf.text.trim().length).toBeGreaterThan(0);
  }

  if (result.keywordResults.length > 0) {
    expect(result.allKeywordsPassed).toBe(true);
  }

  console.log(`\n✅  TC-10 Passed`);
  console.log(`    Email    : "${result.subject}"`);
  console.log(`    Body     : ${result.body.length} chars`);
  console.log(`    Files    : ${result.attachmentNames.join(', ')}`);
  console.log(`    PDFs     : ${result.pdfs.length}`);
  console.log(`    Keywords : ${result.allKeywordsPassed ? '✅ All passed' : '❌ Some failed'}`);
});
