# Outlook 365 — Microsoft Graph API Automation

Reads Outlook emails, downloads attachments, extracts and asserts PDF content — **no browser required**.

---

## How it works

```
Azure AD App → MSAL Token → Graph API → Email Body + Attachments → PDF Text → Console + Assertions
```

---

## 1. Azure App Registration (one-time setup)

### 1.1 Create the app

1. Go to [portal.azure.com](https://portal.azure.com)
2. **Azure Active Directory** → **App registrations** → **New registration**
3. Name: `OutlookAutomation` (any name)
4. Supported account types: **Accounts in this organizational directory only**
5. Click **Register**

### 1.2 Copy your IDs

From the app **Overview** page:

- **Application (client) ID** → paste into `GRAPH_CLIENT_ID` in `.env`
- **Directory (tenant) ID**   → paste into `GRAPH_TENANT_ID` in `.env`

### 1.3 Add API permissions

1. Go to **API permissions** → **Add a permission** → **Microsoft Graph**
2. Select **Delegated permissions** and add:
   - `Mail.Read`
   - `Mail.ReadWrite`
   - `offline_access`
3. If using `client_credentials` mode, also add **Application permissions**:
   - `Mail.Read`
   - `Mail.ReadWrite`
4. Click **Grant admin consent for \<your-org\>**

### 1.4 Enable public client flows (for device_code / ROPC)

1. Go to **Authentication** → **Add a platform** → **Mobile and desktop applications**
2. Check this redirect URI:
   ```
   https://login.microsoftonline.com/common/oauth2/nativeclient
   ```
3. Scroll down → enable **Allow public client flows** → **Save**

### 1.5 (Optional) Create a client secret (for client_credentials mode only)

1. Go to **Certificates & secrets** → **New client secret**
2. Copy the **Value** → paste into `GRAPH_CLIENT_SECRET` in `.env`

---

## 2. Install

```bash
npm install
```

---

## 3. Configure `.env`

```env
GRAPH_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
GRAPH_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
GRAPH_CLIENT_SECRET=               # only needed for client_credentials mode

AUTH_MODE=device_code              # device_code | client_credentials | username_password
USER_EMAIL=your.email@company.com

TARGET_SUBJECT=Your Email Subject  # partial match
TARGET_SENDER=sender@company.com   # optional
ATTACHMENT_NAME_FILTER=            # empty = download all
PDF_ASSERT_CONTAINS=keyword1,keyword2
```

---

## 4. Run tests

```bash
# All tests (TC-01 through TC-10)
npx jest --runInBand

# Specific test
npx jest --runInBand -t "TC-10"

# With verbose output
npx jest --runInBand --verbose
```

---

## 5. Run as standalone script

```bash
npx ts-node src/index.ts
```

---

## 6. Use the generic method in your own code

```typescript
import { GraphAuthProvider } from './src/auth/GraphAuthProvider';
import { GraphClient }       from './src/client/GraphClient';
import { EmailReader }       from './src/email/EmailReader';
import { readEmailAndAssert } from './src/index';

const config = GraphAuthProvider.fromEnv();
const graph  = GraphClient.create(config);
const reader = new EmailReader(graph, './downloads');

// ✅ Pass any email subject — method handles everything
const result = await readEmailAndAssert(reader, 'Invoice March 2026', {
  sender:     'billing@vendor.com',
  keywords:   ['TOTAL DUE', 'Company Ltd', '2026'],
  nameFilter: '.pdf',               // '' = download all attachments
});

// result.body              → full email text
// result.pdfs              → array of PdfResult (text, pages, size)
// result.keywordResults    → per-keyword pass/fail
// result.allKeywordsPassed → boolean summary
```

---

## 7. Auth mode comparison

| Mode | MFA | Admin consent | Best for |
|------|-----|---------------|----------|
| `device_code` | ✅ Yes | Not required | Interactive use, recommended |
| `client_credentials` | N/A | Required | CI/CD pipelines, no user interaction |
| `username_password` | ❌ No | Not required | Test environments only |

### Token caching

`device_code` mode persists the token to `token-cache.json` (configurable via `TOKEN_CACHE_FILE`).
Subsequent runs refresh silently — no login prompt until the token expires.

---

## 8. Project structure

```
outlook-graph-api/
├── src/
│   ├── auth/
│   │   └── GraphAuthProvider.ts   # MSAL: device_code, client_credentials, ROPC
│   ├── client/
│   │   └── GraphClient.ts         # MS Graph client wrapper
│   ├── email/
│   │   └── EmailReader.ts         # listEmails, readBody, listAttachments, download
│   ├── pdf/
│   │   └── PdfProcessor.ts        # read, print, assertKeywords, saveText
│   ├── utils/
│   │   └── helpers.ts             # printEmailContent, Bajaj assertions, file utils
│   └── index.ts                   # readEmailAndAssert() generic method + CLI entry
├── tests/
│   └── email.test.ts              # TC-01 through TC-10 Jest tests
├── downloads/                     # saved attachments + extracted .txt files
├── .env                           # config (do not commit)
├── package.json
├── tsconfig.json
└── README.md
```

---

## 9. Graph API endpoints used

| Operation | Endpoint |
|-----------|----------|
| List inbox | `GET /me/mailFolders/inbox/messages?$filter=...` |
| Search all | `GET /me/messages?$filter=contains(subject,'...')` |
| Read body | `GET /me/messages/{id}?$select=body` |
| List attachments | `GET /me/messages/{id}/attachments` |
| Download attachment | `GET /me/messages/{id}/attachments/{attId}/$value` |
| App-only (CC) | `GET /users/{email}/mailFolders/inbox/messages` |

---

## Differences vs. Playwright version

| Aspect | Playwright | Graph API |
|--------|-----------|-----------|
| Browser required | ✅ Yes | ❌ No |
| Selectors / DOM | Complex | None |
| MFA support | ✅ Browser | ✅ device_code |
| Speed | Slow | Fast |
| Headless CI | Harder | Easy |
| Rate limits | None | 4 req/sec per app |
