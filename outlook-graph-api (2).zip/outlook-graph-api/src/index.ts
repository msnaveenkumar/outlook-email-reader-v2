import * as dotenv from 'dotenv';
import * as fs from 'fs';
import * as path from 'path';
import { GraphAuthProvider } from './auth/GraphAuthProvider';
import { GraphClient }       from './client/GraphClient';
import { EmailReader, EmailFilter, EmailInfo, DownloadedFile } from './email/EmailReader';
import { PdfProcessor, PdfResult, KeywordAssertion }           from './pdf/PdfProcessor';
import { printEmailContent, printConfig }                       from './utils/helpers';

dotenv.config();

// ═══════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════

export interface EmailAssertOptions {
  sender?:      string;       // optional sender filter
  nameFilter?:  string;       // attachment name filter (empty = download all)
  keywords?:    string[];     // must appear in every PDF
  downloadDir?: string;       // override download directory
}

export interface EmailAssertResult {
  subject:           string;
  sender:            string;
  receivedDate:      string;
  body:              string;
  attachmentNames:   string[];
  downloadedFiles:   DownloadedFile[];
  pdfs:              PdfResult[];
  keywordResults:    KeywordAssertion[];
  allKeywordsPassed: boolean;
}

// ═══════════════════════════════════════════════════════════════════════════
// readEmailAndAssert — GENERIC METHOD
// ═══════════════════════════════════════════════════════════════════════════

/**
 * GENERIC REUSABLE METHOD
 *
 * Pass a subject string → the method:
 *   1. Searches the mailbox for the email
 *   2. Reads and prints the FULL email body
 *   3. Downloads ALL attachments
 *   4. For every PDF: reads and prints the full text
 *   5. Asserts every keyword appears in every PDF text
 *   6. Saves extracted text as .txt sibling files
 *   7. Saves a JSON report
 *   8. Returns the full result for further Jest assertions
 *
 * @param reader   EmailReader instance (connected to Graph API)
 * @param subject  Subject keyword to find the email (partial match)
 * @param opts     Optional filters and keyword assertions
 *
 * @example
 *   const result = await readEmailAndAssert(reader, 'Invoice March 2026', {
 *     keywords:   ['TOTAL DUE', '2026', 'Company Ltd'],
 *     nameFilter: '.pdf',
 *   });
 *   expect(result.allKeywordsPassed).toBe(true);
 */
export async function readEmailAndAssert(
  reader:  EmailReader,
  subject: string,
  opts:    EmailAssertOptions = {}
): Promise<EmailAssertResult> {

  const downloadDir = opts.downloadDir
    ?? process.env.DOWNLOAD_DIR
    ?? './downloads';
  const keywords    = opts.keywords ?? [];
  const nameFilter  = opts.nameFilter ?? '';

  // ── Step 1: Find the email ────────────────────────────────────────────────
  console.log(`\n🔍  Searching for email: "${subject}"...`);

  const filter: EmailFilter = {
    subjectContains: subject       || undefined,
    senderContains:  opts.sender   || undefined,
    withinMinutes:   parseInt(process.env.EMAIL_RECEIVED_WITHIN_MINUTES ?? '0', 10) || undefined,
  };

  let emails = await reader.listEmails({ ...filter, top: 50 });

  // Fallback: search all folders if not found in inbox
  if (emails.length === 0 && subject) {
    console.log('    Not in inbox — searching all folders...');
    emails = await reader.searchEmails(subject, 25);
    // Post-filter by sender if needed
    if (opts.sender) {
      const needle = opts.sender.toLowerCase();
      emails = emails.filter(
        (e) => e.sender.toLowerCase().includes(needle)
      );
    }
  }

  if (emails.length === 0) {
    throw new Error(`❌  No email found matching subject: "${subject}"`);
  }

  const target = emails[0];
  console.log(`    ✅  Found  : "${target.subject}"`);
  console.log(`        From   : ${target.sender}`);
  console.log(`        Date   : ${target.receivedDate}`);

  // ── Step 2: Read & print full email body ──────────────────────────────────
  console.log('\n📖  Reading email body...');
  const body = await reader.readEmailBody(target.id);
  printEmailContent(target.subject, target.sender, target.receivedDate, body);

  // ── Step 3: List all attachments ──────────────────────────────────────────
  console.log('\n📎  Listing all attachments...');
  const allAttachments = await reader.listAttachments(target.id);
  console.log(`    Found ${allAttachments.length} attachment(s):`);
  allAttachments.forEach((a) => {
    console.log(`      • ${a.name}  (${(a.size / 1024).toFixed(1)} KB, ${a.contentType})`);
  });

  // ── Step 4: Download all attachments ─────────────────────────────────────
  console.log(`\n⬇️   Downloading ${nameFilter ? `"${nameFilter}" filtered` : 'all'} attachments...`);
  const downloaded = await reader.downloadAllAttachments(target.id, nameFilter);
  console.log(`\n    Total downloaded: ${downloaded.length} file(s)`);
  downloaded.forEach((f) => {
    console.log(`      • ${f.filename}  (${(f.sizeBytes / 1024).toFixed(1)} KB)${f.isPdf ? ' 📄' : ''}`);
  });

  // ── Step 5: Process every PDF ─────────────────────────────────────────────
  const pdfFiles     = downloaded.filter((f) => f.isPdf);
  const pdfResults:   PdfResult[]        = [];
  const allKwResults: KeywordAssertion[] = [];

  // If no PDFs were downloaded, check for existing ones in downloadDir
  const pdfPaths = pdfFiles.length > 0
    ? pdfFiles.map((f) => f.downloadPath)
    : fs.readdirSync(path.resolve(downloadDir))
        .filter((f) => f.toLowerCase().endsWith('.pdf'))
        .map((f) => path.join(path.resolve(downloadDir), f));

  if (pdfPaths.length === 0) {
    console.log('\n    ℹ️   No PDF files to process.');
  }

  for (const pdfPath of pdfPaths) {
    console.log(`\n📄  Processing: ${path.basename(pdfPath)}`);

    // Read + extract text
    const result = await PdfProcessor.read(pdfPath);
    pdfResults.push(result);

    // Print FULL PDF text to console
    PdfProcessor.printFull(result);

    // Save extracted text as .txt file next to the PDF
    PdfProcessor.saveText(pdfPath, result.text);

    // Run keyword assertions
    if (keywords.length > 0) {
      const kwResults = PdfProcessor.assertKeywords(result.text, keywords);
      PdfProcessor.printKeywordResults(result.filename, kwResults);
      allKwResults.push(...kwResults);
    }
  }

  // ── Step 6: Summary ───────────────────────────────────────────────────────
  const allPassed = allKwResults.every((r) => r.found);

  console.log('\n' + '═'.repeat(72));
  console.log('  SUMMARY');
  console.log('═'.repeat(72));
  console.log(`  Email    : "${target.subject}"`);
  console.log(`  From     : ${target.sender}`);
  console.log(`  Body     : ${body.length} characters`);
  console.log(`  Attach   : ${allAttachments.length} total, ${downloaded.length} downloaded`);
  console.log(`  PDFs     : ${pdfResults.length} processed`);
  if (allKwResults.length > 0) {
    const passed = allKwResults.filter((r) => r.found).length;
    console.log(`  Keywords : ${passed}/${allKwResults.length} passed ${allPassed ? '✅' : '❌'}`);
  }
  console.log('═'.repeat(72) + '\n');

  // Save JSON report
  const reportPath = path.join(path.resolve(downloadDir), `report-${Date.now()}.json`);
  const report = {
    timestamp:         new Date().toISOString(),
    email: {
      subject:       target.subject,
      sender:        target.sender,
      receivedDate:  target.receivedDate,
      bodyLength:    body.length,
    },
    attachments:       allAttachments.map((a) => ({ name: a.name, sizeKb: (a.size / 1024).toFixed(1) })),
    downloaded:        downloaded.map((f) => ({ filename: f.filename, sizeKb: (f.sizeBytes / 1024).toFixed(1), isPdf: f.isPdf })),
    pdfs:              pdfResults.map((p) => ({ file: p.filename, sizeKb: p.sizeKb.toFixed(1), pages: p.numPages, chars: p.text.length })),
    keywordAssertions: allKwResults,
    allKeywordsPassed: allPassed,
  };
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), 'utf-8');
  console.log(`📋  Report → ${reportPath}`);

  return {
    subject:           target.subject,
    sender:            target.sender,
    receivedDate:      target.receivedDate,
    body,
    attachmentNames:   allAttachments.map((a) => a.name),
    downloadedFiles:   downloaded,
    pdfs:              pdfResults,
    keywordResults:    allKwResults,
    allKeywordsPassed: allPassed,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPORTS — everything tests and other modules need
// ═══════════════════════════════════════════════════════════════════════════

export { GraphAuthProvider } from './auth/GraphAuthProvider';
export { GraphClient }       from './client/GraphClient';
export { EmailReader }       from './email/EmailReader';
export { PdfProcessor }      from './pdf/PdfProcessor';
export * from './utils/helpers';

// ═══════════════════════════════════════════════════════════════════════════
// STANDALONE ENTRY POINT
// Run: npx ts-node src/index.ts
// ═══════════════════════════════════════════════════════════════════════════

if (require.main === module) {
  (async () => {
    const config = GraphAuthProvider.fromEnv();
    const graph  = GraphClient.create(config);
    const reader = new EmailReader(graph, process.env.DOWNLOAD_DIR ?? './downloads');

    const subject     = process.env.TARGET_SUBJECT ?? '';
    const sender      = process.env.TARGET_SENDER;
    const keywords    = (process.env.PDF_ASSERT_CONTAINS ?? '').split(',').map((s) => s.trim()).filter(Boolean);
    const nameFilter  = process.env.ATTACHMENT_NAME_FILTER ?? '';

    printConfig(
      process.env.USER_EMAIL    ?? 'me',
      process.env.AUTH_MODE     ?? 'device_code',
      subject,
      sender ?? '',
      parseInt(process.env.EMAIL_RECEIVED_WITHIN_MINUTES ?? '0', 10),
      nameFilter,
      keywords
    );

    if (!subject) {
      console.error('❌  Set TARGET_SUBJECT in .env or pass as env var');
      process.exit(1);
    }

    try {
      const result = await readEmailAndAssert(reader, subject, { sender, keywords, nameFilter });
      if (result.keywordResults.some((r) => !r.found)) {
        console.error('❌  Some keyword assertions FAILED');
        process.exit(1);
      }
      console.log('✅  All assertions PASSED');
    } catch (err) {
      console.error('❌  Error:', (err as Error).message);
      process.exit(1);
    }
  })();
}
