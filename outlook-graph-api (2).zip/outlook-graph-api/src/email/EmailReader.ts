import * as fs from 'fs';
import * as path from 'path';
import { GraphClient } from '../client/GraphClient';

// ═══════════════════════════════════════════════════════════════════════════
// TYPES — Microsoft Graph response shapes
// ═══════════════════════════════════════════════════════════════════════════

export interface GraphMessage {
  id:               string;
  subject:          string;
  receivedDateTime: string;
  from: {
    emailAddress: { name: string; address: string };
  };
  body: {
    contentType: 'html' | 'text';
    content:     string;
  };
  hasAttachments: boolean;
  importance:     string;
  isRead:         boolean;
  bodyPreview:    string;
  attachments?:   GraphAttachment[];
}

export interface GraphAttachment {
  id:              string;
  name:            string;
  size:            number;
  contentType:     string;
  contentBytes?:   string;        // base64 (when $expand=attachments and small enough)
  '@odata.type':  string;
}

export interface EmailFilter {
  subjectContains?: string;   // OData $filter on subject (partial, case-insensitive)
  senderContains?:  string;   // filter sender name/address
  hasAttachments?:  boolean;  // only emails that have attachments
  withinMinutes?:   number;   // received in last N minutes (0 = disabled)
  top?:             number;   // max emails to return (default 50)
}

export interface EmailInfo {
  id:             string;
  subject:        string;
  sender:         string;       // "Name <email>"
  receivedDate:   string;       // ISO string from Graph
  hasAttachments: boolean;
  bodyPreview:    string;
}

export interface DownloadedFile {
  filename:     string;
  downloadPath: string;
  sizeBytes:    number;
  isPdf:        boolean;
  contentType:  string;
}

// ═══════════════════════════════════════════════════════════════════════════
// EmailReader
// All Outlook mailbox operations via Microsoft Graph API.
// ═══════════════════════════════════════════════════════════════════════════

export class EmailReader {
  private readonly graph: GraphClient;
  private readonly downloadDir: string;

  constructor(graph: GraphClient, downloadDir = './downloads') {
    this.graph       = graph;
    this.downloadDir = path.resolve(downloadDir);
    if (!fs.existsSync(this.downloadDir)) {
      fs.mkdirSync(this.downloadDir, { recursive: true });
    }
  }

  // ── 1. List emails ────────────────────────────────────────────────────────

  /**
   * Fetches inbox messages filtered by subject, sender, date, and attachments.
   * Uses OData $filter for server-side filtering (fast), plus JS post-filtering.
   *
   * @param filter  EmailFilter options
   * @returns       Array of EmailInfo (metadata only — no body/attachments yet)
   */
  async listEmails(filter: EmailFilter = {}): Promise<EmailInfo[]> {
    const top  = filter.top ?? 50;
    const parts: string[] = [];

    // Build OData $filter string
    if (filter.subjectContains) {
      // Graph supports contains() in OData for strings
      parts.push(`contains(subject, '${this.escapeOdata(filter.subjectContains)}')`);
    }
    if (filter.hasAttachments === true) {
      parts.push(`hasAttachments eq true`);
    }
    if (filter.withinMinutes && filter.withinMinutes > 0) {
      const since = new Date(Date.now() - filter.withinMinutes * 60_000).toISOString();
      parts.push(`receivedDateTime ge ${since}`);
    }

    const odataFilter = parts.join(' and ');
    const url = `${this.graph.mailbox}/mailFolders/inbox/messages`;

    const resp: { value: GraphMessage[] } = await this.graph.get(url, {
      select:  ['id', 'subject', 'from', 'receivedDateTime', 'hasAttachments', 'bodyPreview', 'isRead'],
      filter:  odataFilter || undefined,
      top,
      orderby: 'receivedDateTime desc',
    });

    let messages = resp.value ?? [];

    // JS post-filter for sender (Graph doesn't support contains() on from/emailAddress)
    if (filter.senderContains) {
      const needle = filter.senderContains.toLowerCase();
      messages = messages.filter(
        (m) =>
          m.from?.emailAddress?.name?.toLowerCase().includes(needle) ||
          m.from?.emailAddress?.address?.toLowerCase().includes(needle)
      );
    }

    return messages.map((m) => this.toEmailInfo(m));
  }

  /**
   * Search inbox + sent + all folders using Graph's search API.
   * Use when the target email is not in inbox (e.g. archived).
   */
  async searchEmails(query: string, top = 25): Promise<EmailInfo[]> {
    const url = `${this.graph.mailbox}/messages`;
    const resp: { value: GraphMessage[] } = await this.graph.get(url, {
      select:  ['id', 'subject', 'from', 'receivedDateTime', 'hasAttachments', 'bodyPreview'],
      filter:  `contains(subject, '${this.escapeOdata(query)}')`,
      top,
      orderby: 'receivedDateTime desc',
    });

    return (resp.value ?? []).map((m) => this.toEmailInfo(m));
  }

  // ── 2. Read email ─────────────────────────────────────────────────────────

  /**
   * Fetches the full message body (HTML or plain text).
   * Strips HTML tags and collapses whitespace for cleaner console output.
   */
  async readEmailBody(emailId: string): Promise<string> {
    const url  = `${this.graph.mailbox}/messages/${emailId}`;
    const msg: GraphMessage = await this.graph.get(url, {
      select: ['body'],
    });

    const raw = msg.body?.content ?? '';
    if (msg.body?.contentType === 'html') {
      return this.stripHtml(raw);
    }
    return raw;
  }

  /**
   * Fetches full message details including body AND expanded attachments list.
   */
  async readEmailFull(emailId: string): Promise<GraphMessage> {
    const url = `${this.graph.mailbox}/messages/${emailId}?$expand=attachments`;
    return this.graph.get<GraphMessage>(url);
  }

  // ── 3. Attachments ────────────────────────────────────────────────────────

  /**
   * Lists all attachments on a message (metadata only).
   * Filters by optional name filter (substring / glob / extension).
   */
  async listAttachments(emailId: string, nameFilter = ''): Promise<GraphAttachment[]> {
    const url = `${this.graph.mailbox}/messages/${emailId}/attachments`;
    const resp: { value: GraphAttachment[] } = await this.graph.get(url, {
      select: ['id', 'name', 'size', 'contentType', '@odata.type'],
    });

    const all = (resp.value ?? []).filter(
      (a) => a['@odata.type'] === '#microsoft.graph.fileAttachment'
    );

    if (!nameFilter) return all;
    return all.filter((a) => this.matchFilter(a.name, nameFilter));
  }

  /**
   * Downloads one attachment by ID and saves it to downloadDir.
   * Returns the DownloadedFile descriptor.
   */
  async downloadAttachment(emailId: string, attachment: GraphAttachment): Promise<DownloadedFile> {
    const url    = `${this.graph.mailbox}/messages/${emailId}/attachments/${attachment.id}/$value`;
    const buffer = await this.graph.getBuffer(url);

    const safeName    = attachment.name.replace(/[/\\:*?"<>|]/g, '_');
    const destPath    = path.join(this.downloadDir, safeName);
    fs.writeFileSync(destPath, buffer);

    return {
      filename:     attachment.name,
      downloadPath: destPath,
      sizeBytes:    buffer.length,
      isPdf:        attachment.name.toLowerCase().endsWith('.pdf') ||
                    attachment.contentType === 'application/pdf',
      contentType:  attachment.contentType,
    };
  }

  /**
   * Downloads ALL attachments on a message (filtered by nameFilter if set).
   * Returns array of DownloadedFile descriptors.
   */
  async downloadAllAttachments(emailId: string, nameFilter = ''): Promise<DownloadedFile[]> {
    const attachments = await this.listAttachments(emailId, nameFilter);
    const results: DownloadedFile[] = [];

    for (const att of attachments) {
      console.log(`    ⬇️   Downloading: ${att.name} (${(att.size / 1024).toFixed(1)} KB)...`);
      const file = await this.downloadAttachment(emailId, att);
      results.push(file);
      console.log(`        ✅  Saved → ${file.downloadPath}`);
    }

    return results;
  }

  // ── 4. Poll / wait for email ──────────────────────────────────────────────

  /**
   * Polls the inbox until a matching email appears or the timeout expires.
   */
  async waitForEmail(
    filter: EmailFilter,
    timeoutMs   = 300_000,
    intervalMs  = 15_000
  ): Promise<EmailInfo[]> {
    const start = Date.now();

    while (Date.now() - start < timeoutMs) {
      const emails = await this.listEmails(filter);
      if (emails.length > 0) return emails;

      const elapsed = Math.round((Date.now() - start) / 1000);
      const remain  = Math.round((timeoutMs - (Date.now() - start)) / 1000);
      console.log(`    ⏰  No match yet — ${elapsed}s elapsed, ${remain}s remaining...`);
      await new Promise((r) => setTimeout(r, intervalMs));
    }

    throw new Error(`Timed out after ${timeoutMs / 1000}s waiting for email`);
  }

  // ── 5. Mark as read ───────────────────────────────────────────────────────

  async markAsRead(emailId: string): Promise<void> {
    const url = `${this.graph.mailbox}/messages/${emailId}`;
    await this.graph['client']?.api(url).patch({ isRead: true });
  }

  // ── Private helpers ───────────────────────────────────────────────────────

  private toEmailInfo(m: GraphMessage): EmailInfo {
    const from = m.from?.emailAddress;
    const sender = from ? `${from.name} <${from.address}>` : 'Unknown';
    return {
      id:             m.id,
      subject:        m.subject ?? '(no subject)',
      sender,
      receivedDate:   m.receivedDateTime,
      hasAttachments: m.hasAttachments,
      bodyPreview:    m.bodyPreview ?? '',
    };
  }

  private escapeOdata(s: string): string {
    return s.replace(/'/g, "''");
  }

  private matchFilter(filename: string, filter: string): boolean {
    if (!filter) return true;
    const fname   = filename.toLowerCase();
    const filters = filter.split('|').map((f) => f.trim().toLowerCase()).filter(Boolean);
    return filters.some((f) => {
      if (f.includes('*')) {
        const pat = f.replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
        return new RegExp(`^${pat}$`).test(fname);
      }
      if (f.startsWith('.')) return fname.endsWith(f);
      return fname.includes(f);
    });
  }

  /** Strip HTML tags and decode common entities for console-friendly output. */
  private stripHtml(html: string): string {
    return html
      .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&')
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'")
      .replace(/[ \t]{2,}/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }
}
