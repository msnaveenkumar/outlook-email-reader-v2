import * as fs from 'fs';
import * as path from 'path';

// ═══════════════════════════════════════════════════════════════════════════
// SHARED TYPES
// ═══════════════════════════════════════════════════════════════════════════

export interface BajajCertificateFields {
  policyNo:       string;
  productName:    string;
  policyholder:   string;
  sumAssured:     string;
  totalPremium:   string;
  lifePremium:    string;
  healthPremium:  string;
  premiumDueDate: string;
  financialYear:  string;
}

export interface BajajAssertionResult {
  field:    string;
  expected: string;
  found:    boolean;
  status:   '✅ PASS' | '❌ FAIL';
}

// ═══════════════════════════════════════════════════════════════════════════
// CONSOLE PRINTERS
// ═══════════════════════════════════════════════════════════════════════════

const W = 72;

function box(title: string): void {
  console.log('\n' + '═'.repeat(W));
  const inner = ` ${title} `;
  const pad   = Math.max(0, W - inner.length);
  const lp    = Math.floor(pad / 2);
  console.log(`║${' '.repeat(lp)}${inner}${' '.repeat(pad - lp)}║`);
  console.log('═'.repeat(W));
}

function wrap(text: string, indent = '  '): void {
  const maxW = W - indent.length;
  for (const rawLine of text.split('\n')) {
    const line = rawLine.trimEnd();
    if (line.length === 0) { console.log(''); continue; }
    for (let i = 0; i < line.length; i += maxW) {
      console.log(indent + line.slice(i, i + maxW));
    }
  }
}

/**
 * Prints email metadata + FULL body to the console.
 */
export function printEmailContent(
  subject:      string,
  sender:       string,
  receivedDate: string,
  body:         string
): void {
  box('EMAIL CONTENT');
  console.log(`  Subject  : ${subject}`);
  console.log(`  From     : ${sender}`);
  console.log(`  Received : ${receivedDate}`);
  console.log('─'.repeat(W));
  console.log('  BODY:');
  console.log('─'.repeat(W));
  wrap(body);
  console.log('═'.repeat(W) + '\n');
}

/**
 * Prints startup config banner.
 */
export function printConfig(
  userEmail:    string,
  authMode:     string,
  subject:      string,
  sender:       string,
  withinMin:    number,
  attFilter:    string,
  keywords:     string[]
): void {
  console.log('\n╔══════════════════════════════════════════════════════════╗');
  console.log('║         OUTLOOK GRAPH API — AUTOMATION CONFIG             ║');
  console.log('╠══════════════════════════════════════════════════════════╣');
  console.log(`║  Mailbox            : ${userEmail.padEnd(34)}║`);
  console.log(`║  Auth mode          : ${authMode.padEnd(34)}║`);
  console.log(`║  Subject filter     : ${(subject  || '(none)').padEnd(34)}║`);
  console.log(`║  Sender filter      : ${(sender   || '(none)').padEnd(34)}║`);
  console.log(`║  Time window        : ${(withinMin ? `last ${withinMin} min` : 'all time').padEnd(34)}║`);
  console.log(`║  Attachment filter  : ${(attFilter || '(all)').padEnd(34)}║`);
  console.log(`║  PDF keywords       : ${(keywords.join(',') || '(none)').padEnd(34)}║`);
  console.log('╚══════════════════════════════════════════════════════════╝\n');
}

// ═══════════════════════════════════════════════════════════════════════════
// BAJAJ LEGACY ASSERTIONS (TC-09)
// ═══════════════════════════════════════════════════════════════════════════

export function assertBajajCertificate(
  pdfText:  string,
  expected: BajajCertificateFields
): BajajAssertionResult[] {
  const text = pdfText.replace(/\s+/g, ' ').toUpperCase();
  const checks: Array<{ field: string; expected: string }> = [
    { field: 'Policyholder Name',    expected: expected.policyholder.toUpperCase() },
    { field: 'Policy Number',        expected: expected.policyNo },
    { field: 'Product Name',         expected: expected.productName.toUpperCase() },
    { field: 'Sum Assured',          expected: expected.sumAssured },
    { field: 'Total Premium Amount', expected: expected.totalPremium },
    { field: 'Life Insurance Prem',  expected: expected.lifePremium },
    { field: 'Health Care Premium',  expected: expected.healthPremium },
    { field: 'Premium Due Date',     expected: expected.premiumDueDate },
    { field: 'Financial Year',       expected: expected.financialYear },
  ];
  return checks.map(({ field, expected: val }) => {
    const found = text.includes(val.replace(/\s+/g, ' ').toUpperCase());
    return { field, expected: val, found, status: found ? '✅ PASS' : '❌ FAIL' };
  });
}

export function printBajajResults(results: BajajAssertionResult[]): void {
  const W2 = 62;
  console.log('\n' + '═'.repeat(W2));
  console.log('  BAJAJ LIFE INSURANCE — CERTIFICATE FIELD ASSERTIONS');
  console.log('═'.repeat(W2));
  const maxField = Math.max(...results.map((r) => r.field.length));
  for (const r of results) {
    console.log(`  ${r.status}  ${r.field.padEnd(maxField)}  →  "${r.expected}"`);
  }
  const passed = results.filter((r) => r.found).length;
  console.log('─'.repeat(W2));
  console.log(`  Total: ${results.length}  |  Passed: ${passed}  |  Failed: ${results.length - passed}`);
  console.log('═'.repeat(W2) + '\n');
}

// ═══════════════════════════════════════════════════════════════════════════
// FILE UTILITIES
// ═══════════════════════════════════════════════════════════════════════════

export function ensureDir(dirPath: string): string {
  const resolved = path.resolve(dirPath);
  if (!fs.existsSync(resolved)) fs.mkdirSync(resolved, { recursive: true });
  return resolved;
}

export function listFiles(dirPath: string, ext?: string): string[] {
  const resolved = path.resolve(dirPath);
  if (!fs.existsSync(resolved)) return [];
  return fs.readdirSync(resolved)
    .filter((f) => !ext || f.toLowerCase().endsWith(ext))
    .map((f) => path.join(resolved, f));
}
