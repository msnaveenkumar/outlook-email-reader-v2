import * as fs from 'fs';
import * as path from 'path';
import {
  PublicClientApplication,
  ConfidentialClientApplication,
  LogLevel,
  AuthenticationResult,
} from '@azure/msal-node';
import { AuthenticationProvider } from '@microsoft/microsoft-graph-client';

// ─── Types ───────────────────────────────────────────────────────────────────

export type AuthMode = 'device_code' | 'client_credentials' | 'username_password';

export interface AuthConfig {
  clientId:       string;
  tenantId:       string;
  clientSecret?:  string;
  userEmail?:     string;
  userPassword?:  string;
  tokenCacheFile: string;
  mode:           AuthMode;
}

// ─── Scopes ──────────────────────────────────────────────────────────────────

const DELEGATED_SCOPES = [
  'https://graph.microsoft.com/Mail.Read',
  'https://graph.microsoft.com/Mail.ReadWrite',
  'offline_access',
];

const APP_SCOPES = ['https://graph.microsoft.com/.default'];

// ═══════════════════════════════════════════════════════════════════════════
// GraphAuthProvider
// Implements Microsoft Graph's AuthenticationProvider interface.
//
// Supports three auth flows:
//   device_code        — interactive browser login (MFA-compatible, recommended)
//   client_credentials — app-only token, no user interaction needed
//   username_password  — ROPC, no MFA, for testing only
// ═══════════════════════════════════════════════════════════════════════════

export class GraphAuthProvider implements AuthenticationProvider {
  private readonly config: AuthConfig;
  private accessToken: string | null = null;
  private tokenExpiry: Date | null   = null;

  constructor(config: AuthConfig) {
    this.config = config;
  }

  // ── AuthenticationProvider implementation ─────────────────────────────────

  async getAccessToken(): Promise<string> {
    // Reuse cached token — 5-minute refresh buffer
    if (
      this.accessToken &&
      this.tokenExpiry &&
      new Date() < new Date(this.tokenExpiry.getTime() - 300_000)
    ) {
      return this.accessToken;
    }
    const result = await this.acquireToken();
    this.accessToken = result.accessToken;
    this.tokenExpiry = result.expiresOn ?? new Date(Date.now() + 3_600_000);
    return this.accessToken;
  }

  // ── Dispatch to correct flow ──────────────────────────────────────────────

  private async acquireToken(): Promise<AuthenticationResult> {
    switch (this.config.mode) {
      case 'device_code':        return this.acquireDeviceCode();
      case 'client_credentials': return this.acquireClientCredentials();
      case 'username_password':  return this.acquireUsernamePassword();
      default:
        throw new Error(`Unknown AUTH_MODE: ${String(this.config.mode)}`);
    }
  }

  // ── Device Code flow ──────────────────────────────────────────────────────
  // Step 1: Try silent refresh from persisted token cache (token-cache.json)
  // Step 2: Fall back to interactive device code if needed

  private async acquireDeviceCode(): Promise<AuthenticationResult> {
    const cache = this.loadCache();
    const cacheObj = { data: cache };

    const pca = new PublicClientApplication({
      auth: {
        clientId:  this.config.clientId,
        authority: `https://login.microsoftonline.com/${this.config.tenantId}`,
      },
      cache: {
        cachePlugin: {
          beforeCacheAccess: async (ctx) => {
            ctx.tokenCache.deserialize(cacheObj.data);
          },
          afterCacheAccess: async (ctx) => {
            if (ctx.cacheHasChanged) {
              cacheObj.data = ctx.tokenCache.serialize();
              this.saveCache(cacheObj.data);
            }
          },
        },
      },
      system: { loggerOptions: { logLevel: LogLevel.Error, piiLoggingEnabled: false } },
    });

    // Try silent from cached accounts
    const accounts = await pca.getTokenCache().getAllAccounts();
    for (const account of accounts) {
      try {
        const result = await pca.acquireTokenSilent({
          scopes: DELEGATED_SCOPES,
          account,
        });
        if (result) {
          console.log(`🔑  Token refreshed silently for ${account.username}`);
          return result;
        }
      } catch {
        // silent failed — will do device code below
      }
    }

    // Interactive device code
    console.log('\n' + '═'.repeat(62));
    console.log('  MICROSOFT SIGN-IN REQUIRED (device_code mode)');
    console.log('═'.repeat(62));
    const result = await pca.acquireTokenByDeviceCode({
      scopes: DELEGATED_SCOPES,
      deviceCodeCallback: (response) => {
        console.log(`  1. Open : ${response.verificationUri}`);
        console.log(`  2. Enter: ${response.userCode}`);
        console.log(`  3. Login: ${this.config.userEmail ?? 'your Microsoft account'}`);
        console.log('═'.repeat(62));
        console.log('  Waiting for sign-in...\n');
      },
    });

    if (!result) throw new Error('Device code auth returned null');
    console.log(`✅  Signed in as: ${result.account?.username}\n`);
    return result;
  }

  // ── Client Credentials (app-only) ────────────────────────────────────────
  // Reads any user's mailbox. Requires admin-consented Application permission.

  private async acquireClientCredentials(): Promise<AuthenticationResult> {
    if (!this.config.clientSecret) {
      throw new Error('GRAPH_CLIENT_SECRET is required for client_credentials mode');
    }

    const cca = new ConfidentialClientApplication({
      auth: {
        clientId:     this.config.clientId,
        tenantId:     this.config.tenantId,
        clientSecret: this.config.clientSecret,
      },
      system: { loggerOptions: { logLevel: LogLevel.Error, piiLoggingEnabled: false } },
    });

    const result = await cca.acquireTokenByClientCredential({ scopes: APP_SCOPES });
    if (!result) throw new Error('Client credentials auth returned null');
    console.log(`🔑  App-only token acquired (client_credentials)\n`);
    return result;
  }

  // ── Username + Password ROPC ──────────────────────────────────────────────
  // Deprecated by Microsoft. No MFA support. Use only in test environments.

  private async acquireUsernamePassword(): Promise<AuthenticationResult> {
    if (!this.config.userEmail || !this.config.userPassword) {
      throw new Error('USER_EMAIL and USER_PASSWORD required for username_password mode');
    }

    const pca = new PublicClientApplication({
      auth: {
        clientId:  this.config.clientId,
        authority: `https://login.microsoftonline.com/${this.config.tenantId}`,
      },
      system: { loggerOptions: { logLevel: LogLevel.Error, piiLoggingEnabled: false } },
    });

    const result = await pca.acquireTokenByUsernamePassword({
      scopes:   DELEGATED_SCOPES,
      username: this.config.userEmail,
      password: this.config.userPassword,
    });
    if (!result) throw new Error('Username/password auth returned null');
    console.log(`✅  Signed in as: ${result.account?.username} (ROPC)\n`);
    return result;
  }

  // ── Cache helpers ─────────────────────────────────────────────────────────

  private loadCache(): string {
    try {
      const p = path.resolve(this.config.tokenCacheFile);
      if (fs.existsSync(p)) return fs.readFileSync(p, 'utf-8');
    } catch { /* ignore */ }
    return '{}';
  }

  private saveCache(data: string): void {
    try {
      fs.writeFileSync(path.resolve(this.config.tokenCacheFile), data, 'utf-8');
    } catch { /* ignore */ }
  }

  // ── Factory ───────────────────────────────────────────────────────────────

  /** Read auth config from environment variables. */
  static fromEnv(): AuthConfig {
    const clientId = process.env.GRAPH_CLIENT_ID ?? '';
    const tenantId = process.env.GRAPH_TENANT_ID ?? '';

    if (!clientId || clientId === 'your-client-id-here') {
      throw new Error(
        '❌  GRAPH_CLIENT_ID not configured.\n' +
        '    Register an Azure App and update .env — see README.md.'
      );
    }
    if (!tenantId || tenantId === 'your-tenant-id-here') {
      throw new Error(
        '❌  GRAPH_TENANT_ID not configured.\n' +
        '    Register an Azure App and update .env — see README.md.'
      );
    }

    return {
      clientId,
      tenantId,
      clientSecret:   process.env.GRAPH_CLIENT_SECRET,
      userEmail:      process.env.USER_EMAIL,
      userPassword:   process.env.USER_PASSWORD,
      tokenCacheFile: process.env.TOKEN_CACHE_FILE ?? './token-cache.json',
      mode:           (process.env.AUTH_MODE ?? 'device_code') as AuthMode,
    };
  }
}
