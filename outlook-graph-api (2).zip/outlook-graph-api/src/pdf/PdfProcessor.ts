import * as fs from 'fs';
import * as path from 'path';
import pdfParse from 'pdf-parse';

// ═══════════════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════════════

export interface PdfResult {
  filePath:  string;
  filename:  string;
  text:      string;
  numPages:  number;
  sizeKb:    number;
  info:      Record<string, unknown>;
}

export interface KeywordAssertion {
  keyword: string;
  found:   boolean;
  status:  '✅ PASS' | '❌ FAIL';
}

// ═══════════════════════════════════════════════════════════════════════════
// PdfProcessor
// Static utilities for reading, printing and asserting PDF content.
// ═══════════════════════════════════════════════════════════════════════════

export class PdfProcessor {

  // ── Read ─────────────────────────────────────────────────────────────────

  /** Extract text, page count, size and metadata from a PDF file. */
  static async read(filePath: string): Promise<PdfResult> {
    const absPath = path.resolve(filePath);
    if (!fs.existsSync(absPath)) throw new Error(`PDF not found: ${absPath}`);

    const buffer = fs.readFileSync(absPath);
    const data   = await pdfParse(buffer);
    const stat   = fs.statSync(absPath);

    return {
      filePath:  absPath,
      filename:  path.basename(absPath),
      text:      data.text,
      numPages:  data.numpages,
      sizeKb:    stat.size / 1024,
      info:      data.info as Record<string, unknown>,
    };
  }

  // ── Print ─────────────────────────────────────────────────────────────────

  /**
   * Prints the COMPLETE extracted PDF text to the console.
   * Includes a header with file metadata and full body wrapped at 72 chars.
   */
  static printFull(result: PdfResult): void {
    const W = 72;
    PdfProcessor.box(`PDF: ${result.filename}`, W);
    console.log(`  File    : ${result.filePath}`);
    console.log(`  Size    : ${result.sizeKb.toFixed(1)} KB`);
    console.log(`  Pages   : ${result.numPages}`);
    console.log(`  Chars   : ${result.text.length}`);

    const info = result.info as Record<string, string | undefined>;
    if (info.Author)   console.log(`  Author  : ${info.Author}`);
    if (info.Creator)  console.log(`  Creator : ${info.Creator}`);
    if (info.Producer) console.log(`  Producer: ${info.Producer}`);

    console.log('─'.repeat(W));
    console.log('  FULL EXTRACTED TEXT:');
    console.log('─'.repeat(W));
    PdfProcessor.wrap(result.text, '  ', W);
    console.log('═'.repeat(W) + '\n');
  }

  // ── Keyword assertions ────────────────────────────────────────────────────

  /**
   * Generic keyword assertion against PDF text.
   *
   * @param pdfText   Full text extracted from a PDF
   * @param keywords  Array of strings that must all appear in the text
   *
   * Normalises whitespace before matching — handles PDF line-wrapping
   * that can split a phrase across lines (e.g. "LIFE_SHEILD_NE\nW").
   */
  static assertKeywords(pdfText: string, keywords: string[]): KeywordAssertion[] {
    const normalised = pdfText.replace(/\s+/g, ' ').toUpperCase();
    return keywords.map((kw) => {
      const found = normalised.includes(kw.replace(/\s+/g, ' ').toUpperCase());
      return { keyword: kw, found, status: found ? '✅ PASS' : '❌ FAIL' };
    });
  }

  /** Print a formatted keyword assertion table. */
  static printKeywordResults(filename: string, results: KeywordAssertion[]): void {
    const W = 72;
    PdfProcessor.box(`KEYWORD ASSERTIONS — ${filename}`, W);
    const maxKw = Math.max(...results.map((r) => r.keyword.length), 20);
    console.log(`  ${'KEYWORD'.padEnd(maxKw)}  STATUS`);
    console.log(`  ${'-'.repeat(maxKw)}  -------`);
    for (const r of results) {
      console.log(`  ${r.keyword.padEnd(maxKw)}  ${r.status}`);
    }
    const passed = results.filter((r) => r.found).length;
    const failed = results.length - passed;
    console.log('─'.repeat(W));
    console.log(`  Total: ${results.length}   ✅ Passed: ${passed}   ❌ Failed: ${failed}`);
    console.log('═'.repeat(W) + '\n');
  }

  // ── Save extracted text ───────────────────────────────────────────────────

  /** Save the extracted text to a sibling .txt file next to the PDF. */
  static saveText(pdfPath: string, text: string): string {
    const outPath = pdfPath.replace(/\.pdf$/i, '_extracted.txt');
    fs.writeFileSync(outPath, text, 'utf-8');
    console.log(`  📝  Text saved → ${outPath}`);
    return outPath;
  }

  // ── Console helpers ───────────────────────────────────────────────────────

  private static box(title: string, W: number): void {
    console.log('\n' + '═'.repeat(W));
    const inner = ` ${title} `;
    const pad   = Math.max(0, W - inner.length);
    const lp    = Math.floor(pad / 2);
    console.log(`║${' '.repeat(lp)}${inner}${' '.repeat(pad - lp)}║`);
    console.log('═'.repeat(W));
  }

  private static wrap(text: string, indent: string, W: number): void {
    const maxW = W - indent.length;
    for (const rawLine of text.split('\n')) {
      const line = rawLine.trimEnd();
      if (line.length === 0) { console.log(''); continue; }
      for (let i = 0; i < line.length; i += maxW) {
        console.log(indent + line.slice(i, i + maxW));
      }
    }
  }
}
