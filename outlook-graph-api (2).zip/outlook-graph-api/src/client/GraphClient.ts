import { Client } from '@microsoft/microsoft-graph-client';
import 'isomorphic-fetch';
import { GraphAuthProvider, AuthConfig } from '../auth/GraphAuthProvider';

// ═══════════════════════════════════════════════════════════════════════════
// GraphClient
// Thin wrapper around @microsoft/microsoft-graph-client.
// Automatically injects the access token via GraphAuthProvider.
// ═══════════════════════════════════════════════════════════════════════════

export class GraphClient {
  private readonly client: Client;
  readonly userEmail: string;

  private constructor(client: Client, userEmail: string) {
    this.client    = client;
    this.userEmail = userEmail;
  }

  /** Factory — create from an AuthConfig. */
  static create(config: AuthConfig): GraphClient {
    const authProvider = new GraphAuthProvider(config);
    const client = Client.initWithMiddleware({ authProvider });
    return new GraphClient(client, config.userEmail ?? 'me');
  }

  /**
   * The base mailbox path:
   *   delegated auth      → /me
   *   client_credentials  → /users/{email}
   */
  get mailbox(): string {
    return this.userEmail && this.userEmail !== 'me'
      ? `/users/${this.userEmail}`
      : '/me';
  }

  /** GET with optional OData query params. */
  async get<T>(
    path: string,
    opts: { select?: string[]; filter?: string; top?: number; orderby?: string } = {}
  ): Promise<T> {
    let api = this.client.api(path);
    if (opts.select?.length)  api = api.select(opts.select);
    if (opts.filter)           api = api.filter(opts.filter);
    if (opts.top)              api = api.top(opts.top);
    if (opts.orderby)          api = api.orderby(opts.orderby);
    return api.get() as Promise<T>;
  }

  /** GET binary content (attachment download). Returns Buffer. */
  async getBuffer(path: string): Promise<Buffer> {
    const ab: ArrayBuffer = await this.client
      .api(path)
      .responseType('arraybuffer' as any)
      .get();
    return Buffer.from(ab);
  }
}
