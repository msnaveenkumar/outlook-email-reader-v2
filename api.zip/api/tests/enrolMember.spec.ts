import { test, expect } from "@playwright/test";
import { loadXMLTemplate, replaceValues } from "../utils/xmlTemplate";
import { sendSOAPRequest } from "../utils/soapClient";

test("Enrol Member SOAP API", async () => {

  const template = loadXMLTemplate("templates/enrolMember.xml");

  const testData = {
    CustDOB: "15/06/1990",
    FirstName: "Naveen",
    LastName: "Kumar",
    Mobile: "0411111111",
    Email: "test@test.com",
    Address: "1 Pony Street",
    Suburb: "WOLLONGONG",
    State: "NSW",
    PostCode: "2500"
  };

  const requestXML = replaceValues(template, testData);

  console.log("SOAP Request:", requestXML);

  const response = await sendSOAPRequest(requestXML);

  console.log("SOAP Response:", response);

  expect(response).toContain("Success");

});