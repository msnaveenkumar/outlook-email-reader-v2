import fs from "fs";

export function loadXMLTemplate(path: string) {
  return fs.readFileSync(path, "utf8");
}

export function replaceValues(xml: string, data: any) {

  let updatedXML = xml;

  for (const key in data) {
    updatedXML = updatedXML.replace(
      new RegExp(`{{${key}}}`, "g"),
      data[key]
    );
  }

  return updatedXML;
}