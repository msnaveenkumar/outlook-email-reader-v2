import axios from "axios";

export async function sendSOAPRequest(xmlBody: string) {

  const url = "https://YOUR-SOAP-ENDPOINT";

  const response = await axios.post(
    url,
    xmlBody,
    {
      headers: {
        "Content-Type": "text/xml;charset=UTF-8"
      }
    }
  );

  return response.data;
}