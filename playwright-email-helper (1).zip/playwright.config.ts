import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './src/tests',
  reporter: [
    ['list'],
    ['allure-playwright']
  ],
  timeout: 120000
});
