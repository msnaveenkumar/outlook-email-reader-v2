import { Client } from "@microsoft/microsoft-graph-client";
import { ConfidentialClientApplication } from "@azure/msal-node";
import fs from "fs";
import path from "path";

export class EmailHelper {

  private client!: Client;

  constructor(
    private clientId: string,
    private tenantId: string,
    private clientSecret: string,
    private userEmail: string
  ) {}

  async init() {
    const cca = new ConfidentialClientApplication({
      auth: {
        clientId: this.clientId,
        authority: `https://login.microsoftonline.com/${this.tenantId}`,
        clientSecret: this.clientSecret,
      },
    });

    const tokenResponse = await cca.acquireTokenByClientCredential({
      scopes: ["https://graph.microsoft.com/.default"],
    });

    this.client = Client.init({
      authProvider: (done) =>
        done(null, tokenResponse?.accessToken || ""),
    });
  }

  async waitForEmail(subject: string, minutes: number, timeout = 60000) {
    const start = Date.now();

    while (Date.now() - start < timeout) {

      const sinceTime = new Date(Date.now() - minutes * 60 * 1000).toISOString();

      const messages = await this.client
        .api(`/users/${this.userEmail}/messages`)
        .filter(`receivedDateTime ge ${sinceTime} and contains(subject,'${subject}')`)
        .orderby("receivedDateTime desc")
        .get();

      if (messages.value.length > 0) {
        return messages.value[0];
      }

      await new Promise(res => setTimeout(res, 5000));
    }

    throw new Error("Email not received within timeout");
  }

  async downloadPdf(messageId: string): Promise<string> {

    const attachments = await this.client
      .api(`/users/${this.userEmail}/messages/${messageId}/attachments`)
      .get();

    const pdf = attachments.value.find((a: any) =>
      a.name.endsWith(".pdf")
    );

    if (!pdf) throw new Error("PDF not found");

    const buffer = Buffer.from(pdf.contentBytes, "base64");

    const filePath = path.join(process.cwd(), "downloads", pdf.name);
    fs.writeFileSync(filePath, buffer);

    return filePath;
  }

  async moveEmail(messageId: string, folderName: string) {

    const folders = await this.client
      .api(`/users/${this.userEmail}/mailFolders`)
      .get();

    const folder = folders.value.find((f: any) =>
      f.displayName === folderName
    );

    if (!folder) throw new Error(`Folder ${folderName} not found`);

    await this.client
      .api(`/users/${this.userEmail}/messages/${messageId}/move`)
      .post({ destinationId: folder.id });
  }
}
