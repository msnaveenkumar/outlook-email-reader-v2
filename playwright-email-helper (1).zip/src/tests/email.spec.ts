import { test, expect } from "@playwright/test";
import { EmailHelper } from "../helpers/EmailHelper";
import { extractReceiptNumber, getPdfText } from "../utils/pdfReader";
import { attachPdf } from "../utils/allureHelper";
import dotenv from "dotenv";

dotenv.config();

test("Dynamic PDF Receipt Validation", async () => {

  const helper = new EmailHelper(
    process.env.CLIENT_ID!,
    process.env.TENANT_ID!,
    process.env.CLIENT_SECRET!,
    process.env.USER_EMAIL!
  );

  await helper.init();

  const email = await helper.waitForEmail("PREMIUM RECEIPT", 10, 120000);

  expect(email).toBeTruthy();

  const pdfPath = await helper.downloadPdf(email.id);

  const extractedReceipt = await extractReceiptNumber(pdfPath);

  expect(extractedReceipt).toBe(process.env.EXPECTED_RECEIPT_NO);

  const pdfText = await getPdfText(pdfPath);
  expect(pdfText).toContain("PREMIUM RECEIPT");

  attachPdf(pdfPath);

  await helper.moveEmail(email.id, "Processed");
});
