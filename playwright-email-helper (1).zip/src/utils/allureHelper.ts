import { allure } from "allure-playwright";
import fs from "fs";

export function attachPdf(filePath: string) {
  const content = fs.readFileSync(filePath);
  allure.attachment("Validated PDF", content, "application/pdf");
}
