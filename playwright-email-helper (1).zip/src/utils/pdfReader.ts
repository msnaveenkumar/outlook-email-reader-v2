import fs from "fs";
import pdf from "pdf-parse";

export async function extractReceiptNumber(filePath: string): Promise<string | null> {
  const data = await pdf(fs.readFileSync(filePath));
  const text = data.text;

  const match = text.match(/Receipt\s*No\.?:?\s*(\d+)/i);
  return match ? match[1] : null;
}

export async function getPdfText(filePath: string): Promise<string> {
  const data = await pdf(fs.readFileSync(filePath));
  return data.text;
}
